import fs from "node:fs";
const O="/tmp/bakeoff"; const out={};
for (const m of ["minimax","deepseek","glm"]) for (const f of fs.readdirSync(`${O}/out/${m}`)) {
  const j=JSON.parse(fs.readFileSync(`${O}/out/${m}/${f}`,"utf8")); let findings=null, status="ok";
  const blocks=[...j.content.matchAll(/```json\s*([\s\S]*?)```/g)];
  let txt = blocks.length? blocks[blocks.length-1][1] : null;
  if(!txt){ const k=j.content.lastIndexOf("["); const e=j.content.lastIndexOf("]"); if(j.doneReason==="stop" && k>=0&&e>k) txt=j.content.slice(k,e+1); }
  if(txt){ try{ findings=JSON.parse(txt); if(!Array.isArray(findings)) {findings=null;status="garbled"} }catch{ status="garbled" } } else status = j.doneReason==="length"?"truncated":"no-json";
  out[`${m}/${j.change}-r${j.run}`]={m,change:j.change,run:j.run,status,findings,wallMs:j.wallMs,apiMs:j.apiMs,pt:j.promptTokens,ot:j.outputTokens,done:j.doneReason,attempts:j.attempts};
}
fs.writeFileSync(`${O}/parsed.json`,JSON.stringify(out,null,1));
const s={}; for(const v of Object.values(out)){ s[v.m]??={}; s[v.m][v.status]=(s[v.m][v.status]??0)+1 } console.log(s);
