import fs from "node:fs";
const O="/tmp/bakeoff",K=JSON.parse(fs.readFileSync(`${O}/key/answer-key.json`)),P=JSON.parse(fs.readFileSync(`${O}/parsed.json`)),M=JSON.parse(fs.readFileSync(`${O}/judge/md-map.json`));
const L={};for(const k of K)Object.assign(L,JSON.parse(fs.readFileSync(`${O}/judge/labels-${k.id}.json`)));
const res={};
for(const [id,m] of Object.entries(M)){const l=L[id];if(!l){console.log("missing",id);continue}
 const c=id.slice(0,3);const r=(res[m.model+"/"+c+"-r"+m.run]??={C:0,S:0,R:0,F:0});r[{CATCH:"C",SYMPTOM:"S",REAL:"R",FALSE:"F"}[l.label]]++;}
const out={};
for(const m of ["minimax","deepseek"]){const o={catch:0,sym:0,F:0,Fctl:0,R:0,rev:0,byType:{},cons:{both:0,one:0,none:0},wall:[],api:[],pt:0,ot:0,perChange:{}};
 for(const k of K){const rr=[1,2].map(n=>res[`${m}/${k.id}-r${n}`]??{C:0,S:0,R:0,F:0});
  for(const n of [1,2]){const p=P[`${m}/${k.id}-r${n}`];o.rev++;o.wall.push(p.wallMs);o.api.push(p.apiMs);o.pt+=p.pt;o.ot+=p.ot;}
  rr.forEach(r=>{o.F+=r.F;o.R+=r.R;if(k.kind=="control")o.Fctl+=r.F;});
  if(k.kind=="bug"){const cs=rr.map(r=>r.C>0),ss=rr.map(r=>r.C>0||r.S>0);o.catch+=cs.filter(Boolean).length;o.sym+=rr.filter(r=>r.C==0&&r.S>0).length;
   const n=cs.filter(Boolean).length;o.cons[n==2?"both":n==1?"one":"none"]++;o.perChange[k.id]=`${k.type}: r1 ${rr[0].C?"C":rr[0].S?"S":"-"}, r2 ${rr[1].C?"C":rr[1].S?"S":"-"}`;
   (o.byType[k.type]??=[0,0]);o.byType[k.type][0]+=n;o.byType[k.type][1]+=2;}}
 const avg=a=>Math.round(a.reduce((x,y)=>x+y,0)/a.length/100)/10;o.wallAvg=avg(o.wall);o.apiAvg=avg(o.api);delete o.wall;delete o.api;out[m]=o;}
console.log(JSON.stringify(out,null,1));
