# Change c05 (merge commit 201cdac) — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c05.diff

ANSWER KEY: file apps/server/src/services/notifications.ts, line ~171 (line in the new file), type: inverted check
Bug: The unread/read filters are swapped: Unread returns read notifications and vice versa.

## Findings (anonymous ids)

### c05-F001
file: apps/server/src/services/notifications.ts  line: 171  severity: high
The status filter conditions are reversed. `status=unread` uses `isNotNull(notifications.readAt)` and therefore returns read notifications, while `status=read` uses `isNull(notifications.readAt)` and returns unread notifications. The expected predicates should be `isNull(readAt)` for unread and `isNotNull(readAt)` for read.

### c05-F002
file: apps/server/src/services/notifications.ts  line: 167  severity: high
The status predicates are reversed: `status=unread` checks `isNotNull(notifications.readAt)` and `status=read` checks `isNull(...)`. This returns read notifications for the unread filter and unread notifications for the read filter, breaking the primary feature and contradicting the added test expectations.

### c05-F003
file: apps/web/src/pages/Notifications.tsx  line: 242  severity: low
Validating the persisted level with `s.level in LEVEL` also accepts inherited properties such as `toString` and `constructor`. A corrupted or manually edited sessionStorage value can therefore produce an invalid level, causing a 400 request or undefined labels. Use an own-property check or a direct enum-membership check.

### c05-F004
file: apps/server/src/services/notifications.ts  line: 172  severity: high
Status filter is inverted: `status === "unread"` uses `isNotNull(notifications.readAt)` (i.e. read rows) and `status === "read"` uses `isNull(notifications.readAt)` (unread rows). Unread/read filters return the opposite set.

### c05-F005
file: apps/server/test/notifications.test.ts  line: 172  severity: high
Test asserts the inverted behavior (`status=unread` -> ["b","c"] where `a` was the one marked read, and `status=read` -> ["a"]). This locks in the bug rather than catching it; the expectations should be swapped.

### c05-F006
file: apps/web/src/pages/Notifications.tsx  line: 296  severity: medium
`usePoll` is called with a key that changes with `qs`, but the callback is also recreated each render. If `usePoll` keys off the callback identity (typical), this refetches on every render; if it keys off the string, the previous in-flight request isn't cancelled on filter change and stale results can land. Either way the filtered list can flicker or show results for the wrong filter. Verify the hook's contract and pass a stable callback / rely on the key.

### c05-F007
file: apps/web/src/pages/Notifications.tsx  line: 305  severity: medium
`last.current` is updated during render (`if (loaded) last.current = loaded;`). Mutating a ref during render is unsafe under React 18 StrictMode/concurrent rendering and can leak stale items across filter changes (e.g. switching from company A to company B briefly shows A's items). Move the assignment into an effect keyed on the filter.

### c05-F008
file: apps/web/src/pages/Notifications.tsx  line: 316  severity: medium
`read()` calls `reload()` which calls both `onChanged()` and `filtered.reload()`. When filters are inactive, `filtered` was never fetched (the callback returns `Promise.resolve(null)`), so `filtered.reload()` is a no-op — fine — but when filters are active, `onChanged()` also triggers the parent feed reload, doubling requests. More importantly, `filtered.reload()` is called unconditionally even when the poll was never started; confirm `usePoll` tolerates that. Also, after marking items read while `status=unread`, the just-read items should disappear — verify the poll actually refetches (not just returns cached data).

### c05-F009
file: apps/web/src/pages/Notifications.tsx  line: 322  severity: low
`full = items.length >= 50` assumes the default page size is 50, but the server default is 50 only when `limit` is omitted; the summary text "Showing the latest N" is misleading if the server default changes or if a `limit` is ever passed. Minor, but the magic number duplicates the server default.

### c05-F010
file: apps/web/src/pages/Notifications.tsx  line: 268  severity: low
`readFilters` validates `level` with `s.level in LEVEL`, which is true for inherited keys like `"toString"`/`"constructor"`. A crafted sessionStorage value could set `level` to a non-NotifyLevel string, which then gets sent as `level=toString` and 400s the request. Use `Object.prototype.hasOwnProperty.call(LEVEL, s.level)` or an explicit allowlist.

### c05-F011
file: apps/web/src/pages/Notifications.tsx  line: 340  severity: low
`neverAny = !active && feed && !items.length` hides the FilterBar when there are no notifications at all. That's intentional, but it also hides the bar while `feed` is still loading (`feed === null`), so the bar pops in after load. Minor UX; also means the empty-state message and the filter bar can't coexist, which is fine but worth confirming against the design.

### c05-F012
file: apps/server/src/app.ts  line: 708  severity: low
`company` accepts `"none"` or a UUID, but there's no validation that the UUID belongs to the owner's companies. Since the query is scoped to the owner's notifications, a foreign UUID just returns empty — not a leak — but it silently accepts arbitrary UUIDs. Consider validating against the owner's company list for clearer errors, or leave as-is if empty results are acceptable.

### c05-F013
file: apps/server/src/services/notifications.ts  line: 172  severity: high
Status filter is inverted: `status === "unread"` uses `isNotNull(notifications.readAt)` (i.e. read) and `status === "read"` uses `isNull(notifications.readAt)` (i.e. unread). The new test asserts the same inverted behavior, so it passes while the feature is broken for users.

### c05-F014
file: apps/server/test/notifications.test.ts  line: 173  severity: medium
Test encodes the inverted status semantics (`status=unread` expected to return the read notice 'a'? actually expects ['b','c'] which are unread — but the service returns read ones), so it does not catch the bug above; the assertions should be written against the intended behavior and would fail against the current implementation.

### c05-F015
file: apps/web/src/pages/Notifications.tsx  line: 296  severity: medium
With a filter active, 'Mark these read' only marks the currently loaded page (up to 50) of unread items. Older unread items matching the filter stay unread, and the summary text 'Showing the latest N' does not warn the user, so they may believe everything matching the filter was marked read.

### c05-F016
file: apps/web/src/pages/Notifications.tsx  line: 268  severity: low
`s.level in LEVEL` uses the `in` operator on a plain object, so inherited keys like `"toString"` or `"constructor"` pass the check. A crafted sessionStorage value would then produce `LEVEL_PLURAL[level] === undefined` and render 'undefined' in the summary; use `Object.prototype.hasOwnProperty.call(LEVEL, s.level)` or a Set.

### c05-F017
file: apps/web/src/pages/Notifications.tsx  line: 289  severity: low
`neverAny` is computed from the unfiltered `feed` only, so when the unfiltered feed is empty the FilterBar is hidden even if a filter is active (e.g. restored from sessionStorage) and the filtered query would return results — the user cannot clear the filter from the UI in that state.
