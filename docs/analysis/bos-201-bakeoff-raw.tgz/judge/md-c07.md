# Change c07 (merge commit 181e874) — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c07.diff

ANSWER KEY: file apps/server/src/services/self-deploy.ts, line ~164 (line in the new file), type: missing null / empty check
Bug: Removed the guard for no deployed commit: with deployed null every open hand-apply to-do looks 'caught up' (null !== fromCommit) and is cleared.

## Findings (anonymous ids)

### c07-F001
file: apps/server/src/services/self-deploy.ts  line: 84  severity: medium
The hand-apply step runs `git checkout main` and then `git merge --ff-only <approved-commit>`. If `main` has already advanced beyond the approved commit, this cannot fast-forward to the older commit and the step fails; if local `main` has diverged, it may also apply something other than the pinned commit. This contradicts the instruction that the approved commit be pinned for the case where main has moved. The instructions should checkout/reset directly to the approved commit (or otherwise use a safe detached checkout at that SHA) before rebuilding.

### c07-F002
file: apps/server/src/services/decisions.ts  line: 176  severity: high
clearOwnerTodo updates rows by dedupeKey alone, without filtering by companyId. The key is derived only from the commit, so if two companies have an owner to-do for the same commit, clearing one company's to-do can mark the other company's to-do as answered. Add the company ID to the key or include eq(decisions.companyId, ...) in the update.

### c07-F003
file: apps/server/src/services/self-deploy.ts  line: 164  severity: medium
clearDoneOwnerTodos selects owner to-dos for every company and then clears them using the current host's available.deployed commit. Because clearOwnerTodo is also not company-scoped, a host reporting a changed commit can clear a to-do belonging to a different company when the commit/key matches. Restrict both the query and cleanup to the company that owns the deployment.

### c07-F004
file: apps/server/src/mcp.ts  line: 71  severity: low
ownerActionHint treats any open decision raised by the current agent as covering the reply, even if it concerns another ticket or subject. Such an unrelated decision suppresses the warning and can leave the owner without a queue item for this request. Require the decision to block this ticket, or otherwise verify that it covers the reply's subject.

### c07-F005
file: apps/server/src/mcp.ts  line: 63  severity: high
The 'covering' check treats any open decision raised by this agent as covering the ask, even if it's about a different ticket or unrelated topic. An agent that has any open decision anywhere will never get the hint, defeating the feature. The OR should require the decision to actually block this ticket (or be about it), not just be raised by the same agent.

### c07-F006
file: apps/server/src/mcp.ts  line: 60  severity: medium
OWNER_ASK matches common status words like 'revert', 'roll back', 'try again', 'run the', 'apply it' inside ordinary status reports (e.g. 'I reverted the bad commit', 'I'll try again tomorrow'). This will fire the hint on many plain status replies, producing noise and pushing agents to raise unnecessary decisions.

### c07-F007
file: apps/server/src/services/self-deploy.ts  line: 168  severity: high
The fallback `ctx.commit === a.deployed` clears the to-do when the live commit equals the approved commit — but that's exactly the state right after approval (before the owner has applied anything), since the approved commit is what the host was already running when the offer was raised. Rows without fromCommit will be cleared immediately on the next sync, before the owner does anything. The fallback should require the live commit to have moved past the approved one, not equal it.

### c07-F008
file: apps/server/src/services/self-deploy.ts  line: 163  severity: medium
clearDoneOwnerTodos clears by dedupeKey `owner-todo:self-deploy:${ctx.commit}`, but clearOwnerTodo's WHERE only filters on dedupeKey and status='open' with no companyId. If two companies (or two rows) share the same commit key, the wrong row can be closed. Also, when multiple open to-dos exist for different commits, the loop clears each by its own key, but the summary uses a.deployed for all of them — misleading when several are cleared at once.

### c07-F009
file: apps/server/src/services/decisions.ts  line: 1245  severity: high
The owner_todo branch handles TODO_FAILED by re-opening the row, but there is no explicit handling for TODO_DONE. It relies on the generic answer path below to set status='answered'. Verify that path actually runs for kind='question' with context.type='owner_todo' — if the generic path only handles specific context types or requires a wake target, the 'Done' answer may leave the row open or throw. The test only checks status after the request, not that the generic path is reached for this context type.

### c07-F010
file: apps/server/src/services/decisions.ts  line: 1245  severity: medium
On TODO_FAILED, the code re-opens the row and wakes the CEO only when `!d.raisedByAgentId`. But the generic wake block later in the function wakes `d.raisedByAgentId` with the answer text — for a failed step that's 'A step failed', which is fine, but the note ('their note: ...') is only appended in the generic wake. If the to-do was raised by an agent, that agent gets woken with the failure note; if not, the CEO gets a separate wake. That's OK, but the CEO wake uses reason 'decision' which may collide with dedupe/rate limits — worth confirming.

### c07-F011
file: apps/server/src/services/decisions.ts  line: 1245  severity: medium
The TODO_FAILED path sets status back to 'open' and answer to null, but does not reset `answeredAt` on the row's dedupeKey or re-check that the row is still open. If the row was already closed by clearDoneOwnerTodos between the read and this update (race with the poller), this update will re-open a closed to-do. The update should be guarded with `where(and(eq(id), eq(status,'open')))`.

### c07-F012
file: apps/server/src/services/decisions.ts  line: 1245  severity: medium
The owner_todo branch does not validate that `answer` is one of TODO_DONE/TODO_FAILED. Any other answer (e.g. a stale client sending 'Not now', or a crafted request) falls through to the generic path and closes the row as 'answered' with an arbitrary answer, silently clearing the to-do without the owner confirming the change was applied.

### c07-F013
file: apps/server/src/services/decisions.ts  line: 1245  severity: low
The owner_todo branch does not check `extra.by` / settled. A CEO settling the to-do (or an automated settle) will go through the same path as the owner, which may not be intended for a 'Waiting for you' card.

### c07-F014
file: apps/server/src/services/self-deploy.ts  line: 168  severity: medium
clearDoneOwnerTodos runs on every sync before the early-return checks, but it queries all open owner_todo rows for the company across all targets and clears by key. If the host reports a.deployed that happens to equal ctx.fromCommit for a to-do whose fromCommit was set to a commit that later becomes live again (e.g. a rollback), the to-do is cleared even though the approved change was never applied. The 'caught up' test should require the live commit to be the approved commit or a descendant, not merely 'different from fromCommit'.

### c07-F015
file: apps/server/src/services/self-deploy.ts  line: 168  severity: low
The clearDoneOwnerTodos summary uses `short(a.deployed)` for every cleared to-do, but a to-do may have been approved for a different commit than what's now live (BOS-124 allows landing on a later commit). The activity record will claim the approved change is applied when a different commit is live — misleading audit trail.

### c07-F016
file: apps/server/src/services/decisions.ts  line: 1245  severity: medium
The owner_todo 'Done' path relies on the generic answer flow to close the row, but the generic flow's wake block only fires for `d.kind === 'question' && d.raisedByAgentId`. For a system-raised to-do (raisedByAgentId null), no one is notified that the owner marked it done — the agent that originally raised the approval (ofDecisionId) is not woken. The approval's raiser should be notified so it can proceed.

### c07-F017
file: apps/server/src/services/decisions.ts  line: 1245  severity: low
The owner_todo branch does not clear the `ofDecisionId` linkage or record that the to-do was completed in a way the original approval's raiser can see. Combined with the missing wake above, the agent that raised the approval has no signal that the hand-apply finished.

### c07-F018
file: apps/server/src/services/self-deploy.ts  line: 168  severity: high
clearDoneOwnerTodos clears a to-do whenever `a.deployed !== ctx.fromCommit`. If the host reports a different commit for any reason (e.g. a rollback to an older commit, a manual revert, or a different branch), the to-do is marked done even though the approved change was never applied. The check should confirm the live commit is the approved commit or a descendant, not merely 'different from fromCommit'.

### c07-F019
file: apps/server/src/services/self-deploy.ts  line: 172  severity: medium
clearOwnerTodo is keyed by `owner-todo:self-deploy:${ctx.commit}`, but the loop iterates over all open owner_todos. If two to-dos exist for different commits (e.g. two infra approvals in a row), the first iteration clears the to-do for its own commit, but the second iteration's `clearOwnerTodo` call uses the second to-do's commit key — that's fine — however the `caughtUp` check uses `a.deployed` for both, so both to-dos clear on the same live-commit change even if only one was actually applied. The check should compare against the to-do's own commit, not just 'fromCommit differs'.

### c07-F020
file: apps/server/src/mcp.ts  line: 63  severity: medium
The `covering` query left-joins ticketDependencies on blockerDecisionId and filters with `or(eq(ticketDependencies.blockedTicketId, ticketId), scope.agentId ? eq(decisionsTable.raisedByAgentId, scope.agentId) : sql`false`)`. The `raisedByAgentId` branch matches any open decision raised by this agent, even one unrelated to this ticket — so an agent that has any open decision anywhere suppresses the hint for all its ticket replies. The intent (per the comment) is 'this agent already asked about it', which should be scoped to this ticket (e.g. via the decision's context.ticketId or a dependency link).

### c07-F021
file: apps/server/src/services/decisions.ts  line: 1245  severity: medium
On TODO_FAILED, the decision is reset to open with `answer: null`, but the wake note to the CEO says 'The "Waiting for you" card is still on their queue' — however the wake is only sent when `!d.raisedByAgentId`. For a to-do raised by an agent, the agent is woken by the generic `d.kind === "question" && d.raisedByAgentId` path below, but that path uses `answer` which is now `TODO_FAILED` and the note says 'The owner answered your question ... A step failed' — the agent doesn't get the owner's `note` in a structured way beyond the appended `— their note: ...`. That's acceptable, but the CEO wake path doesn't include the ticket link or the decision id, so the CEO can't easily find the card. Minor, but the note should reference the decision id or link.

### c07-F022
file: apps/server/src/services/decisions.ts  line: 1230  severity: medium
The `owner_todo` answer path only handles TODO_FAILED. For TODO_DONE, it falls through to the generic answered path (status set to answered, answer recorded), which is correct. But the generic wake path below (`d.kind === "question" && d.raisedByAgentId`) will wake the raising agent with 'The owner answered your question ... Done, it's applied' — for a to-do raised by an agent, that's fine. However, for a to-do raised by the system (no raisedByAgentId), nothing wakes anyone on Done, which is fine. No bug here, but the TODO_FAILED path's `if (!d.raisedByAgentId && wake)` means an agent-raised to-do's failure is only surfaced via the generic wake, which uses `answer` = TODO_FAILED and appends the note — acceptable.

### c07-F023
file: apps/server/src/services/decisions.ts  line: 1236  severity: low
The `lastFailure` context is set via `{ ...ctx, lastFailure: ... }`, but `ctx` is the parsed context from the decision row. If the context was stored with `satisfies DecisionContext` and the type is `owner_todo`, spreading it is fine. However, the `answer` is reset to null and `answeredAt` to null, but the `dedupeKey` is left intact — so a subsequent `raiseOwnerTodo` with the same key would conflict and return null, which is correct (the to-do is still open). No bug, but worth confirming the dedupeKey is preserved (it is, since only status/answer/answeredAt/context are updated).

### c07-F024
file: apps/server/src/services/self-deploy.ts  line: 155  severity: low
The `clearDoneOwnerTodos` query filters `sql`${decisions.context}->>'target' = 'server'``, but the `owner_todo` context's `target` field is optional (`target?: "server" | "runner"`). If a to-do is raised without a target (e.g. from a non-self-deploy path in the future), it won't be cleared. Currently only self-deploy raises owner_todos with target='server', so this is fine, but the filter is brittle.

### c07-F025
file: apps/server/src/services/self-deploy.ts  line: 100  severity: low
The handSteps reference `scripts/rebuild-live.sh` and `scripts/deploy.sh --commit ${commit}` — but the rollback step says `scripts/deploy.sh --rollback` without a commit. If the deployer's `--rollback` rolls back to the previous deploy (not necessarily `fromCommit`), the rollback may not restore the exact pre-approval state. The check step says 'it should show ${short(commit)}' — but if the owner applies a later commit (per BOS-124), the check will fail even though the to-do auto-clears. Minor inconsistency between the check text and the auto-clear behavior.

### c07-F026
file: apps/server/src/mcp.ts  line: 55  severity: low
The OWNER_ASK regex includes `run (?:this|it|the|scripts)` and `apply (?:it|this|the|them)` — these will match common status phrases like 'I ran the tests' (no, 'ran' not 'run') but 'the scripts are updated' would match 'the scripts'. Also `revert` and `roll back` match any mention, including 'I did not revert anything'. The regex is heuristic and will produce false positives, causing the hint to appear on status replies. Low severity since the hint is advisory.

### c07-F027
file: apps/server/src/services/decisions.ts  line: 1200  severity: low
When `ctx.infra && answer === APPROVE_HAND_APPLY`, the code raises an owner_todo but does not check whether `raiseOwnerTodo` returned null (dedupe conflict). If a to-do for the same commit already exists (e.g. the owner approved twice, or a previous approval left an open to-do), the new approval is marked answered but no new to-do is created — the existing one remains, which is correct. However, the approval's `ofDecisionId` in the existing to-do points to the old approval, not the new one. Minor.
