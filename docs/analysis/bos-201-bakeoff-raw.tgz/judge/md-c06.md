# Change c06 (merge commit c556de4) — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c06.diff

ANSWER KEY: file apps/server/src/services/decisions.ts, line ~658 (line in the new file), type: error swallowed
Bug: The wake of the CEO for a plan now swallows any failure, so a plan can sit on the ceo rung with nobody woken and no trace.

## Findings (anonymous ids)

### c06-F001
file: apps/server/src/services/sweeps.ts  line: 48  severity: medium
The `alert` dependency was added as a required property of `sweepService` options. Any existing direct callers or tests that construct `sweepService` without an `alert` callback will fail TypeScript compilation, even though the callback is only needed for the stalled-run path.

### c06-F002
file: apps/server/src/services/alert-ladder.ts  line: 282  severity: medium
The new `deps.answer` contract passes `{ settledBy: { agentId }, note }`, but the existing `decisionsService.answer` implementation is documented and used with `extra.by` and does not show support for `settledBy`. If `AnswerExtra` does not include this property, the `app.ts` callback is type-incompatible; if it does not, the passed actor metadata is silently ignored and the owner-facing settled record will not identify the Scrum Master as intended.

### c06-F003
file: apps/server/src/services/alert-ladder.ts  line: 292  severity: medium
The nudge uses `input.runId ?? ctx.runId`. In the MCP `resolve_alert` handler, `input.runId` is the authenticated Scrum Master run ID, while `ctx.runId` is the stalled run that the alert concerns. Consequently, a stalled-run nudge can be recorded or processed against the Scrum Master's run rather than the target run. Use the alert context's `ctx.runId` for this alert.

### c06-F004
file: apps/server/src/services/sweeps.ts  line: 274  severity: high
The stalled-review path calls `opts.alert(...)` unconditionally, but `alert` is a new required dep. Any caller that constructs `sweepService` without it (tests, other entry points, or a future refactor) will throw at runtime on the first stuck review. The stalled-run path guards with `opts.alert ? ... : null`; this one does not.

### c06-F005
file: apps/server/src/app.ts  line: 388  severity: high
`sweepService` is constructed with `alert: (input) => alerts.raise(input)` before `alerts` is declared (`const alerts = alertLadder(...)` appears later). The closure is fine at call time, but if any sweep runs during startup (or a test calls it before `alerts` is assigned) it hits a temporal-dead-zone ReferenceError. Move the `alerts` construction above `sweepService`, or make the dep lazy and assert it is set.

### c06-F006
file: apps/server/src/services/alert-ladder.ts  line: 118  severity: high
`holder` still applies the hourly watchdog-action cap to the Scrum Master rung even when `duty` is true. A stalled run is supposed to reach the Scrum Master first regardless of the watchdog being off, but once the cap is hit the rung is skipped and the alert falls through to the CEO. The `duty` flag should bypass the cap (or the cap should be counted separately for duty alerts).

### c06-F007
file: apps/server/src/services/alert-ladder.ts  line: 300  severity: high
In `resolve`, the nudge lookup uses `ctx.runId` but the nudge call uses `input.runId ?? ctx.runId`. A caller can pass a `runId` in the tool input (it is not validated against the alert) and nudge a different run than the one the alert is about. Drop `input.runId` from the nudge call, or validate it equals `ctx.runId`.

### c06-F008
file: apps/server/src/services/alert-ladder.ts  line: 195  severity: medium
`dutyActor` only checks that the caller is the company's active Scrum Master. It no longer checks the company pause or the watchdog cap that `watchdog.actor` used to enforce. A paused company's Scrum Master can now settle stalled-run alerts (and `mine`/`pass`/`resolve` all go through it), which contradicts the ladder's own rule that a paused company goes straight to the owner.

### c06-F009
file: apps/server/src/services/alert-ladder.ts  line: 285  severity: medium
`canChoose` accepts any option in `options` for a `stalled_run`, but the only options are `KEEP_WAITING` and `CANCEL_RUN`. The nudge guard checks `answer !== CANCEL_RUN`, so `answer: "Keep waiting"` with `nudge: true` fires a nudge — but nothing in the code actually keeps the run alive; the sweep's `keepWaitingMs` logic depends on the decision being answered with `KEEP_WAITING`, which it is, so this is mostly OK, but the `answer` is not validated against the two known constants, so a future option added to `options` would silently be accepted as a stalled-run answer.

### c06-F010
file: apps/server/src/services/decisions.ts  line: 640  severity: medium
The plan-to-CEO ladder is only attached when `tier === "ceo" && !forAgentId`. If a plan approver is named (`forAgentId` set), the plan stays on the approver's queue with no ladder and no 5-minute handover — but the ticket says plan cards routed to the CEO get the handover. A plan routed to a named approver who is the CEO (or who never answers) will sit forever. Either attach the ladder for named approvers too, or document that only the unnamed-CEO case gets the handover.

### c06-F011
file: apps/server/src/services/decisions.ts  line: 760  severity: medium
The permission-request ladder is now attached for every `tier === "ceo"` request, not just temp-file cleanup and working-copy deletes. The wake note's non-temp-cleanup branch is a single generic sentence, but the CEO is now expected to answer arbitrary rule-routed permission requests (e.g. `systemctl restart`) with no guidance on what the command does or what to check. The old code only sent temp-cleanup and working-copy deletes to the CEO; other rule-routed requests went to the owner. This is a behavior change that widens what the CEO is asked to approve without giving it the context the owner had.

### c06-F012
file: apps/server/src/services/decisions.ts  line: 1230  severity: medium
`recentlyAdvised` now selects every answered decision with a `settled` context, not just permissions. The `permissions` variable name and the `ctx as Extract<DecisionContext, { type: "permission" }>` cast are now wrong for non-permission rows: `ctx.explain` and `ctx.tempCleanup` are read off a context that may be a `stalled_run` or a plain question, so `command` and `tempCleanup` will be `undefined`/`false` for those rows. The cast hides the type error but the data is wrong.

### c06-F013
file: apps/server/src/services/decisions.ts  line: 1245  severity: low
`fromAlerts` builds `settled.by` from `actorNames.get(r.actorAgentId) || "the team"`, but `r.actorAgentId` is the Scrum Master who resolved the alert, not necessarily who answered the decision. For a stalled run the SM is the answerer, so this is fine; for a plain alert the SM is also the answerer. But if the SM resolves an alert that was later escalated and answered by the CEO, the audit will attribute the CEO's answer to the SM. The `settled` context on the decision (set by `answer`) is the authoritative source; prefer it.

### c06-F014
file: apps/server/src/services/decisions.ts  line: 1470  severity: low
The wake note now says `${settled.name} settled` when `settled` is set, but `settled` is derived from `extra.settledBy` — which the alert ladder passes as the Scrum Master. For a permission request the CEO answered directly (not via the ladder), `settled` is undefined and the note falls back to `extra.by === "ceo"`, which is correct. But for a stalled run the SM answers via the ladder, so the agent is told "Scrum Master settled your question" — the agent asked the question, not the SM, so the wording is confusing. Minor.

### c06-F015
file: apps/server/src/mcp.ts  line: 1940  severity: low
`resolve_alert` now accepts `answer` and `nudge` but the tool description only mentions them for stalled-run alerts. A caller passing `answer` on a plain alert gets a 409 from `resolve`, which is fine, but the schema does not constrain `answer` to the two stalled-run options, so a typo silently becomes a 409 rather than a validation error.

### c06-F016
file: scripts/host-deployer.sh  line: 425  severity: low
The dedupe grep now uses `grep -qE "\"id\":[[:space:]]*\"$REQ_ID\""`. `$REQ_ID` is validated as a UUID earlier, so it is safe, but the regex is unanchored: a history line containing `"id": "<uuid>"` as a substring of a longer id (e.g. a nested object) would match. The old `grep -qF` had the same weakness, so this is not a regression, but the comment claims it accepts both spacings — it also accepts any whitespace, including newlines, which `grep` line-by-line will not cross, so that is fine.

### c06-F017
file: apps/server/src/app.ts  line: 388  severity: high
sweepService is constructed with `alert: (input) => alerts.raise(input)` before `const alerts = alertLadder(...)` is declared below. The closure captures `alerts` in its temporal dead zone; the first sweep that raises a stalled run or stuck review throws ReferenceError.

### c06-F018
file: apps/server/src/services/alert-ladder.ts  line: 189  severity: high
dutyActor only checks that the caller is the active Scrum Master. It no longer calls watchdog.actor, so a tripped watchdog (watchdogTrippedAt) or a paused company no longer blocks the Scrum Master from resolving/passing stalled-run alerts, defeating the cap/trip safety.

### c06-F019
file: apps/server/src/services/alert-ladder.ts  line: 296  severity: high
The stalled-run resolve path answers with CANCEL_RUN (which sends run.cancel to the runner) without going through watchdog.capOrFail or any hourly cap. Every other watchdog action is capped; this lets the Scrum Master cancel runs unbounded, and the capOrFail call is only on the rewake branch.

### c06-F020
file: apps/server/src/services/alert-ladder.ts  line: 285  severity: high
nudge is called with `runId: input.runId ?? ctx.runId!`. `input.runId` is the MCP tool's own run id (the Scrum Master's run), not the stalled run's id, so the nudge is delivered against the wrong run and the stalled agent is never asked why it is quiet.

### c06-F021
file: apps/server/src/services/decisions.ts  line: 620  severity: high
The plan-approval ladder is built with `rung: "ceo"` but `forAgentId` is never set to the CEO. `place()` only sets `forAgentId` when moving to the scrum_master rung; on the first sweep the CEO rung has no holder, so the card falls straight to the owner instead of waiting 5 minutes with the CEO.

### c06-F022
file: apps/server/src/services/decisions.ts  line: 1230  severity: medium
The `permissions` query dropped `eq(decisions.kind, "permission")` but the mapping still does `ctx.settled!.name` with a non-null assertion. Any answered non-permission decision whose context has a `settled` field (e.g. a plan the CEO answered via the ladder) will throw at runtime when `ctx.settled` is undefined.

### c06-F023
file: apps/server/src/services/decisions.ts  line: 1230  severity: medium
The widened `permissions` query now returns every answered decision with a `settled` context, including plans and stalled runs. Those are also produced by `fromAlerts`, so the same card can appear twice in the advised list (the `alreadyListed` set only dedupes `fromAlerts` against `permissions`, not the reverse ordering).

### c06-F024
file: apps/server/src/services/sweeps.ts  line: 200  severity: medium
Stalled-run alerts are raised with `from: "scrum_master"` and `duty: true`, but `raise()` inserts with `tier: "ceo"` and no `forAgentId`; the Scrum Master only gets it if `place()` runs. If `place()` skips the Scrum Master (e.g. paused, over cap), the card is left on the CEO team queue with no `forAgentId` and no ladder rung holder, and the sweep's `raised` count still increments — the alert is effectively orphaned until the next sweep.

### c06-F025
file: apps/server/src/services/sweeps.ts  line: 260  severity: medium
The stuck-review alert is raised with `from: "ceo"` but `about: [agentId]` (the reviewer). If the CEO is the reviewer, `holder` skips the CEO rung and the card falls to the owner immediately, contradicting the ticket's intent that the CEO sees it first. The `about` should exclude the CEO or the rung should be handled explicitly.

### c06-F026
file: apps/server/src/mcp.ts  line: 1935  severity: medium
`resolve_alert` now accepts `answer` and `nudge` but the tool description only documents them for stalled-run alerts. A Scrum Master can pass `answer` on a plain alert; `resolve` rejects it with 409, but the error message ('needs a choice the Scrum Master can't make') is misleading when the caller supplied a valid-looking answer for a non-stalled alert.

### c06-F027
file: apps/server/src/services/alert-ladder.ts  line: 240  severity: low
`raise()` inserts with `tier: "ceo"` and no `forAgentId`, then relies on `place()` to set the initial rung. Between insert and place, the card is visible on the CEO team queue but not on the Scrum Master's `mine()` (which filters `forAgentId = agentId`). If `place()` throws or is skipped, the card is stranded on the CEO queue with no holder.

### c06-F028
file: apps/web/src/pages/Decisions.tsx  line: 137  severity: low
`settledWord` maps 'Allow once'/'Deny'/'Keep waiting'/'Cancel run'/'Got it' but the `advised` list now includes non-permission decisions (plans, stalled runs) whose answers are arbitrary option strings; those fall through to the raw answer, which is fine, but the summary label 'Settled by the team' now covers CEO-only settlements too, which may confuse the owner about who acted.

### c06-F029
file: scripts/host-deployer.sh  line: 381  severity: low
The new comment says booleans print True/False 'because callers compare against "True"', but the function already did that before this change; the comment is misleading about what changed and the diff does not actually change behavior here.
