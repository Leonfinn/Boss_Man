# Change c04 (merge commit 1aae55a) — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c04.diff

ANSWER KEY: file apps/server/src/services/planning.ts, line ~234 (line in the new file), type: wrong variable
Bug: blockIds maps to e.blocker (the ticket itself) instead of e.blocked, so the 'Blocks' group is always empty.

## Findings (anonymous ids)

### c04-F001
file: apps/server/src/services/planning.ts  line: 231  severity: medium
When this ticket is the blocker, the blocked ticket ID is `e.blocked`, but `blockIds` maps `e.blocker`. Consequently `blocks` resolves to this ticket itself and is filtered out, making the Blocks group empty for all ticket-to-ticket dependencies. It should collect `e.blocked` for edges where `e.blocker === ticketId`.

### c04-F002
file: apps/server/src/services/planning.ts  line: 215  severity: medium
The feature lookup is scoped only by feature ID, not by the ticket's company. If a ticket is assigned a feature belonging to another company, this response exposes that feature's title and status, contrary to the documented own-company restriction.

### c04-F003
file: apps/server/src/services/planning.ts  line: 216  severity: medium
The parent, child, and sibling queries are not constrained to `tickets.companyId`. A malformed or cross-company parent/child relationship would cause titles, states, and references from another company to be returned. Add the current company predicate to these queries (and enforce the relationship invariant at write time).

### c04-F004
file: apps/server/src/services/planning.ts  line: 230  severity: high
The `blocks` IDs are computed incorrectly. For dependencies where the current ticket is the blocker, the blocked ticket is in `blockedTicketId`, but this code maps `blockerTicketId`, which is the current ticket. As a result, `blocks` is always empty (after `others()` removes the current ticket), hiding every ticket that depends on this ticket.

### c04-F005
file: apps/server/src/services/planning.ts  line: 216  severity: medium
The child, sibling, and peer queries are not restricted to `me.companyId`. Although relationships are normally expected to stay within a company, these database relations do not enforce that invariant here, and the endpoint explicitly promises to return only tickets from the ticket's own company. A cross-company parent/child or shared feature/parent relation can expose another company's ticket titles and states. The parent lookup at line 215 has the same missing company constraint.

### c04-F006
file: apps/server/src/services/planning.ts  line: 216  severity: medium
Sub-task and peer queries are silently limited to 200 rows. The web UI can expand a returned group but cannot reveal tickets beyond the server limit, so valid related tickets are omitted from the page without any indication that the list is incomplete.

### c04-F007
file: apps/server/src/services/planning.ts  line: 232  severity: high
blockIds maps e.blocker for edges where e.blocker === ticketId, so it always yields [ticketId] (the ticket itself). The 'Blocks' group will always be empty. Should map e.blocked for edges where e.blocker === ticketId.

### c04-F008
file: apps/server/src/services/planning.ts  line: 238  severity: medium
The mentioned-tickets query filters only by tickets.number (inArray on numbers) without restricting by ticket prefix, so it can pull tickets from other prefixes with the same number. The post-filter on ref mitigates correctness but the query is wrong and could be slow; it should also constrain by prefix or join on the ref.

### c04-F009
file: apps/web/src/components/TicketLinks.tsx  line: 108  severity: medium
Removing the 'Waiting on this' (blocks) list and the 'Open the feature' link from TicketLinks assumes the new Related section always renders. TicketLinks is also used with bare=true elsewhere; those callers lose the blocks list and feature link entirely. Verify all call sites render TicketRelated, or keep the blocks list in TicketLinks.

### c04-F010
file: apps/web/src/components/TicketRelated.tsx  line: 55  severity: low
Guard `if (!r?.subtasks) return null` hides the whole section on any API error or unexpected shape, and is a weak check (should be `if (!r)`). On fetch failure the user sees nothing rather than an error or empty state.

### c04-F011
file: apps/server/src/services/planning.ts  line: 224  severity: low
The mentioned-tickets regex allows any 1-10 char alphanumeric prefix and matches things like 'UTF-8' or 'SHA-256' in descriptions; combined with the number-only query this can surface unrelated tickets. Consider restricting to the company's actual ticket prefix.

### c04-F012
file: apps/server/src/services/planning.ts  line: 232  severity: high
blockIds maps e.blocker instead of e.blocked. For edges where this ticket is the blocker, e.blocked is the ticket being blocked; using e.blocker returns the current ticket's own id, so `blocks` will always be empty after `others()` filters out self.

### c04-F013
file: apps/server/src/services/planning.ts  line: 218  severity: high
parent, children, and siblings queries use `from()` without filtering by `me.companyId`. If a ticket's parentTicketId or featureId points at another company's row (data drift, or a crafted update), the response leaks titles/refs of tickets from other companies. The doc comment claims 'Only tickets in its own company' but the code doesn't enforce it for these three queries.

### c04-F014
file: apps/server/src/services/planning.ts  line: 240  severity: medium
Mention matching is fragile: the regex captures any `WORD-123` token, then the query filters by `tickets.number` only (not prefix), and the post-filter compares `ticketRef(...).toUpperCase()` against the captured token. A body mentioning `ABC-5` will match any ticket in the company whose number is 5 regardless of prefix, and the post-filter only rejects it if the ref string differs — but the query already fetched by number across all prefixes, so unrelated tickets with the same number are pulled in and then filtered out client-side. Worse, if two prefixes share a number, only the matching one survives, but the query cost and potential for confusion is real. Also `` around `[A-Za-z]` won't match refs embedded in markdown like `**BOS-5**` correctly in all cases (it will, but `BOS-5.` etc. is fine). The bigger issue: the number-only query can return tickets from other prefixes and the filter relies on `ticketRef` returning the same prefix casing.

### c04-F015
file: apps/server/src/services/planning.ts  line: 226  severity: medium
`waitIds` filters `e.blocked === ticketId && e.blocker` — the `&& e.blocker` truthiness check is redundant given the type, but more importantly `blockIds` (line 232) uses `e.blocker === ticketId` and then maps `e.blocker!`, which is the current ticket. Combined with the bug above, the `blocks` list is broken. Also `waitIds`/`blockIds` can contain duplicates if multiple dependency rows exist between the same pair; `byIds` doesn't dedupe, so `others()` will emit duplicate rows.

### c04-F016
file: apps/server/src/services/planning.ts  line: 210  severity: low
`type Row = Awaited<ReturnType<ReturnType<typeof from>["limit"]>>[number]` is a brittle type derivation; if `from()` changes shape this silently breaks. Not a runtime bug but fragile.

### c04-F017
file: apps/web/src/components/TicketLinks.tsx  line: 50  severity: medium
The 'Open the feature' link is removed from TicketLinks, and the replacement (TicketRelated's Feature group) only renders when the related endpoint returns a feature. If the related fetch fails or is still loading, the user loses the only in-page link to the feature. Also the feature link is now in the right column, which may be off-screen on narrow layouts.

### c04-F018
file: apps/web/src/components/TicketLinks.tsx  line: 116  severity: high
The 'Waiting on this' (blocks) list is removed from TicketLinks and is supposed to be replaced by the new Blocks group in TicketRelated — but the server's `blocks` computation is broken (see planning.ts line 232), so users lose visibility of tickets waiting on this one entirely. This is a functional regression.

### c04-F019
file: apps/web/src/components/TicketRelated.tsx  line: 55  severity: low
`if (!r?.subtasks) return null` — the guard checks `subtasks` specifically, which is odd; if the API ever returns a shape without `subtasks` but with other fields, the whole section silently disappears. Should check `!r`.

### c04-F020
file: apps/web/src/components/TicketRelated.tsx  line: 30  severity: low
`Group` uses `useState` for `all`, but the component is keyed only by label implicitly (no key on `<Group>` in the parent). When the ticket changes (ticketId prop changes), the `all` state persists across tickets because React reuses the Group instances. Minor, but 'show more' state leaks between tickets.

### c04-F021
file: apps/web/src/components/TicketRelated.tsx  line: 20  severity: low
`openFirst` re-sorts on every render, so the order of rows can shift as polling updates state (e.g. a peer moves to done). Combined with the `all` toggle, the 'show N more' count can change under the user. Not a bug per se, but the sort should be stable/memoized or the server should return a stable order.

### c04-F022
file: apps/server/test/planning.test.ts  line: 130  severity: medium
The test asserts `expect(r.blocks).toEqual([])` for a ticket that has no blockers — it never exercises the `blocks` path with a real blocker, so the `e.blocker` vs `e.blocked` bug in planning.ts is not caught. Add a case where another ticket depends on `me` and assert it appears in `blocks`.

### c04-F023
file: apps/server/test/planning.test.ts  line: 118  severity: low
The test uses `BOS-9999` as a 'matches nothing' case, but the mention query filters by number only across all prefixes; if a ticket with number 9999 existed under any prefix it would be fetched and then filtered. The test doesn't cover the cross-prefix collision case, so the fragile mention logic is untested.
