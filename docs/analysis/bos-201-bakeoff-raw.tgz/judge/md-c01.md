# Change c01 (merge commit 4c4c418) — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c01.diff

ANSWER KEY: file apps/server/src/services/review.ts, line ~474 (line in the new file), type: off-by-one / boundary
Bug: The lock-wait retry loop allows LOCK_RETRY_ATTEMPTS+1 tries (one more than the 6 stated); the give-up check should be >=.

## Findings (anonymous ids)

### c01-F001
file: apps/server/src/services/review.ts  line: 468  severity: medium
The retry limit is evaluated only after another `landOnce` call. Starting at attempt 1, this permits attempts 1–6 to run and then performs attempt 7 before `attempt > LOCK_RETRY_ATTEMPTS` becomes true. Consequently, `LOCK_RETRY_ATTEMPTS = 6` produces seven verify requests and seven lock waits, contradicting the constant's documented meaning and the test expecting exactly six requests. Check the limit before invoking `landOnce`, or otherwise reserve the initial attempt separately.

### c01-F002
file: apps/server/src/services/review.ts  line: 469  severity: medium
The loop performs an initial attempt and then permits attempts 1 through 6 to be followed by another attempt, for 7 total check executions. The test expects LOCK_RETRY_ATTEMPTS (6), so it will observe 7 workspace.verify requests. The exhaustion check should occur before another retry so the total number of attempts matches the configured limit.

### c01-F003
file: apps/server/src/services/review.ts  line: 470  severity: high
Off-by-one in retry count: the loop runs landOnce, and on lock_wait checks `attempt > LOCK_RETRY_ATTEMPTS` before sleeping. With LOCK_RETRY_ATTEMPTS=6 the loop performs 7 landOnce calls (attempts 1..7) before giving up, but the test asserts exactly LOCK_RETRY_ATTEMPTS (6) verify calls and the log says 'try N of 6'. Either the check should be `attempt >= LOCK_RETRY_ATTEMPTS` or the constant/test must be reconciled; as written the test will fail or the message lies.

### c01-F004
file: apps/server/src/services/review.ts  line: 486  severity: high
The retry pause uses a bare `setTimeout` with no cancellation and no leader check. If the server is shutting down or loses leadership during the pause (which can be up to 32 minutes with the doubling), the loop still wakes up and calls landOnce on a process that may no longer be leader, racing the new leader. The catch block handles isLeader loss for exceptions but not for the sleep path.

### c01-F005
file: apps/server/src/services/review.ts  line: 494  severity: high
When the ticket left review during the wait, land() returns `{ outcome: "check_stuck", delivered: null }` without recording anything or raising a decision. The caller (approve/landing flow) treats check_stuck as 'owner has a decision to answer', but no decision exists, so the ticket is left in whatever state it moved to with no record and no card — the exact failure mode the surrounding code is trying to avoid.

### c01-F006
file: apps/server/src/services/review.ts  line: 300  severity: high
The new 'every review is in' branch fires for any reviewerAgentId that has a row on the ticket, including one whose review was overruled or superseded, and it calls this.approve() which re-runs the full approval path. It does not check that the caller's own review is actually approved (only that a row exists), so a reviewer whose review was overruled can restart a merge. It also bypasses the `skipChecks`/landing-in-progress guards that the normal path relies on beyond the two ad-hoc checks here.

### c01-F007
file: apps/server/src/services/review.ts  line: 300  severity: medium
The signoff check queries ticketDependencies joined to decisions with status 'open' but does not filter by kind or by which decision; any open blocker decision on the ticket (not just a check-stuck/merge-stuck one) will block the restart with a misleading 'waiting on the owner's decision' message. Also the query has no limit/order, so behavior is nondeterministic if multiple open decisions exist.

### c01-F008
file: scripts/check-all.sh  line: 60  severity: high
Race in merge priority: the merge check creates its marker file only after `flock -n 9` fails, but a hand-run check that is already polling can observe `merge_waiting` false and grab the lock with `flock -n 9` in the window between the merge check's failed non-blocking attempt and its marker creation. The merge check then blocks on `flock -w` behind the hand-run check, defeating the stated priority. The marker must be created before the first `flock -n` attempt (or the hand-run poll must re-check after acquiring).

### c01-F009
file: scripts/check-all.sh  line: 63  severity: medium
`got` is only assigned in the merge-check branch (`got=no` on failure) and in the hand-run branch (`got=yes`/`got=no`). In the merge-check success path `got` is never set, so the later `[ "${got:-yes}" = no ]` relies on the default. That works today but is fragile: if `got` is inherited from the environment (it is not `local`), a stray `got=no` in the caller's env would make a successful merge check exit 75. Declare `local got` or initialize it explicitly.

### c01-F010
file: scripts/check-all.sh  line: 55  severity: medium
The hand-run poll loop uses `SECONDS` arithmetic and `sleep 1`, but does not re-check `merge_waiting` after `flock -n 9` succeeds — it only checks before. Combined with the marker race above, a hand-run check can acquire the lock and hold it for the full heavy phase while a merge check waits. Also `SECONDS` is a bash builtin; the script is invoked via `sh -c` from the runner (workspace.ts spawns `sh`), and `SECONDS` is not POSIX — under dash this is empty and the loop condition `[ "" -lt "$end" ]` errors or loops forever.

### c01-F011
file: scripts/check-all.sh  line: 52  severity: medium
`merge_waiting` uses `kill -0 "${f##*/}"` on the pid parsed from the filename. If the marker file is named by a pid that has been reused by an unrelated process, the merge check is considered still waiting forever and hand-run checks are starved. There is no timestamp/staleness check on the marker.

### c01-F012
file: apps/server/src/services/review.ts  line: 50  severity: low
`LOCK_RETRY_BASE_MS` is exported as a mutable `let` and mutated by `setLockRetryBase` for tests. Because it is module-global, a test that sets it to 1ms and does not reset it will affect other tests in the same file/process (the afterEach only closes the app). The new tests call setLockRetryBase(1) but never restore the default.

### c01-F013
file: apps/server/src/services/review.ts  line: 47  severity: low
`checkWaitedForLock` matches on exact wording from check-all.sh. If the script's message changes (or a different check command emits exit 75 with similar text), the retry silently stops working and the ticket is sent back as a real failure. The coupling is undocumented in the script beyond a comment; consider a more robust signal (e.g. a distinct exit code reserved for lock-wait, or a structured marker line).

### c01-F014
file: apps/server/src/services/review.ts  line: 470  severity: high
Retry loop condition `attempt > LOCK_RETRY_ATTEMPTS` runs landOnce LOCK_RETRY_ATTEMPTS+1 times (attempts 1..7), but the test asserts exactly LOCK_RETRY_ATTEMPTS verify calls. Off-by-one: either the loop or the test is wrong; as written the owner is asked after 7 tries while the log says 6.

### c01-F015
file: apps/server/src/services/review.ts  line: 478  severity: high
The heartbeat setInterval is only cleared in the `finally` around the sleep. If `ticketWithRepo`, `record`, or the post-sleep state check throws, the interval keeps firing forever (unref'd but still a leak per failed landing) and the outer catch will raise merge_stuck while the interval keeps touching lastActivityAt.

### c01-F016
file: apps/server/src/services/review.ts  line: 300  severity: high
The new 'every review is in' branch only refuses when `landings.get(ticketId)?.state === 'running'`. After a successful merge the landing entry is 'finished' (or removed), so a second reviewer confirming approval will call approve() again and re-run land() on an already-done ticket — landOnce returns 'done' but the merge_restarted activity is recorded and the ticket is re-touched. Should also refuse when state is 'finished' or the ticket is already done.

### c01-F017
file: apps/server/src/services/review.ts  line: 305  severity: medium
The signoff query joins ticketDependencies→decisions on blockerDecisionId but does not filter by companyId or by decision kind/context. Any open decision that happens to be a blocker for this ticket (e.g. an unrelated owner question) will block the restart with a misleading 'waiting on the owner's decision' message.

### c01-F018
file: apps/server/src/services/review.ts  line: 50  severity: medium
checkWaitedForLock matches the literal string 'check-all: gave up waiting for the heavy-phase lock' but the script emits 'check-all: gave up waiting for the heavy-phase lock $LOCK' — the regex is unanchored so it still matches, but it will also match any output that merely contains that prefix (e.g. an agent's own test echoing it). Combined with exitCode===75 this is narrow enough, but the script's exit 75 is also used by other tools; the match should be anchored to the start of a line.

### c01-F019
file: apps/server/src/services/review.ts  line: 47  severity: medium
setLockRetryBase mutates a module-level `let` that is never reset in afterEach. Tests that set it to 1 leave it at 1 for subsequent tests in the same file, which can mask real timing bugs and make the suite order-dependent.

### c01-F020
file: scripts/check-all.sh  line: 60  severity: high
Race: the merge check does `flock -u 9` then `mkdir -p "$WAITERS"; : >"$WAITERS/$$"`. Between the unlock and the marker creation, a hand-run check that was polling can acquire the lock (merge_waiting sees no marker). The merge check then blocks on `flock -w` behind the hand-run check, defeating the priority. The marker must be created before releasing the lock.

### c01-F021
file: scripts/check-all.sh  line: 55  severity: medium
The hand-run branch polls `flock -n 9` in a loop, but between `merge_waiting` returning false and `flock -n 9` succeeding, a merge check can arrive and create its marker. The hand-run check still wins the lock. The check should re-test merge_waiting after acquiring, or the merge check should be able to preempt (it can't with flock). At minimum the window should be documented; as written the 'merge goes first' guarantee is best-effort only.

### c01-F022
file: scripts/check-all.sh  line: 62  severity: medium
`trap 'rm -f "$WAITERS/$$"' EXIT` is set only in the merge branch, but the marker is also removed explicitly after success. On the `exit 75` path the trap fires and removes it — fine — but if the script is killed by SIGKILL (the runner's timeout path) the marker is left behind. merge_waiting cleans stale markers by pid, so this is recoverable, but a pid can be reused by an unrelated process, causing a hand-run check to be starved indefinitely.

### c01-F023
file: scripts/check-all.sh  line: 50  severity: low
`merge_waiting` iterates `"$WAITERS"/*` and calls `kill -0` on each basename. If a marker file is created by a different user (shared /tmp), `kill -0` fails with EPERM and the marker is treated as stale and removed — a merge check from another user's runner would be silently ignored. The lock path is shared across runners per the comment, so this matters.

### c01-F024
file: scripts/check-all.test.sh  line: 55  severity: medium
The new priority test uses `date +%s%N` to compare acquisition times, but both children are backgrounded and the timestamps are written after the child exits (after CHECK_ALL_STOP_AFTER_LOCK). The comparison `merge.at <= hand.at` therefore measures exit order, not lock-acquisition order; with the stubs both exit immediately after acquiring, so it usually passes, but it does not actually prove the merge check got the lock first — it proves it exited first, which can happen even if the hand-run check acquired first and exited faster.

### c01-F025
file: apps/server/test/review.test.ts  line: 240  severity: low
The 'asks the owner' test asserts `toHaveLength(LOCK_RETRY_ATTEMPTS)` verify calls, but the loop runs LOCK_RETRY_ATTEMPTS+1 times (see off-by-one above). This test will fail as written unless the loop is fixed; if the loop is fixed to match, the test is correct.
