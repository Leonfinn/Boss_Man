# Change c12 (merge commit c772c57) — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c12.diff

ANSWER KEY: file apps/server/src/services/work.ts, line ~197 (line in the new file), type: wrong condition (&& became ||)
Bug: Chat runs now count as working on any ticket (|| instead of &&), so every card shows chat agents as working.

## Findings (anonymous ids)

### c12-F001
file: apps/server/src/services/work.ts  line: 199  severity: medium
`onCard` returns true for any run whose purpose is not `"chat"`, regardless of the card ID. Consequently, a ticketless run with a non-chat purpose is assigned to every ticket, causing unrelated cards to show a working agent and preventing that run from appearing in `withoutTicket`. The purpose check should only qualify runs that actually have `r.ticketId === id`; for example, use `(r.ticketId === id && r.purpose !== "chat") || r.runTicketId === id`.

### c12-F002
file: apps/server/src/services/work.ts  line: 196  severity: medium
`onCard` returns true for every non-chat run because of `(r.purpose !== "chat" || r.ticketId === id)`, without requiring `r.ticketId === id`. Consequently, a run on ticket A is shown as working on every card in the project, and a ticketless non-chat run is attached to cards instead of appearing in `withoutTicket`. The predicate should require a matching ticket for normal runs, while allowing `runTicketId` to associate a run with the ticket it was about.

### c12-F003
file: apps/server/src/services/work.ts  line: 196  severity: high
onCard logic is wrong: `(r.purpose !== "chat" || r.ticketId === id)` makes a chat run count as working on a ticket whenever its ticketId matches, contradicting the comment 'chat runs don't count'. Previously chat runs were excluded entirely. A chat run on a ticket will now light up the card as live work.

### c12-F004
file: apps/server/src/services/work.ts  line: 196  severity: high
`|| r.runTicketId === id` lets a chat run (or any run) attach to a card purely via runTicketId even when purpose is 'chat'. Combined with the previous clause this means chat runs can appear as working on cards, which the old query explicitly excluded with `ne(runs.purpose, "chat")`.

### c12-F005
file: apps/server/src/services/work.ts  line: 232  severity: high
`workingAgents: new Set(everyLive.map((r) => r.agentId)).size` counts distinct agents, but the dashboard's `stats.running` (per the test asserting equality) counts live runs. If one agent has two concurrent live runs, the board and dashboard will disagree — the stated goal of BOS-155. Either the dashboard must also dedupe by agent, or the board must count runs.

### c12-F006
file: apps/server/src/services/dashboard.ts  line: 80  severity: medium
`live` now comes from `liveRuns`, which joins agents and tickets and runs several correlated subqueries per row (originFrom/originNote/wakeNote). The dashboard only needs agentId; this is a heavier query than the previous simple select and may regress dashboard latency. Also `liveRuns` returns rows with `agentId` possibly null (leftJoin), which the dashboard's downstream use of `live` may not expect.

### c12-F007
file: apps/server/src/services/work.ts  line: 195  severity: medium
`everyLive` is fetched for the whole company regardless of whether `ids` is empty, and `withoutCard` is computed with `ids.some(...)` per run — O(runs × tickets). On a large board this is a real cost on every board load. The previous code short-circuited when `ids.length === 0`.

### c12-F008
file: apps/server/src/services/work.ts  line: 197  severity: medium
`withoutCard` uses `!ids.some((id) => onCard(r, id))`, but `ids` only contains tickets on this board's rows. A run on a ticket that exists in the project but is filtered out of `rows` (e.g. done tickets beyond DONE_SHOWN, or archived) will be listed in the 'Working without a ticket' strip even though it does have a ticket. The strip's label and the `withoutTicket` field name are then misleading.

### c12-F009
file: apps/web/src/pages/Board.tsx  line: 645  severity: medium
The 'Working now' button now shows `workingAgents` (distinct agents with any live run, including ticketless ones), but clicking it filters cards by `working` (agents on cards). The count and the filter disagree: with 3 working agents where 1 is ticketless, the button says (3) but only shows cards for 2. This is confusing and contradicts the button's meaning.

### c12-F010
file: apps/web/src/pages/Board.tsx  line: 590  severity: low
`RunLabelLink run={{ ...r, note: r.wakeNote }}` spreads `UnticketedRun` into a run-shaped prop. If `RunLabelLink` expects fields not present (e.g. `outcome`, `endedAt`, `ticketId` shape differences) this may render incorrectly or throw; the type is not verified here. Also `originNote` is passed but the label uses `wakeNote` as `note`, so the nudge reason may not display.

### c12-F011
file: apps/web/src/pages/Board.tsx  line: 590  severity: low
`ago(r.startedAt)` is imported from `./Dashboard`. If `ago` is not exported from Dashboard (it's used internally there), this is a build error; the diff doesn't show an export change. Worth confirming.

### c12-F012
file: apps/server/src/services/runs.ts  line: 30  severity: low
`liveRuns` uses `asc` and `and`/`eq`/`isNull` but the diff doesn't show the import line being updated. If `asc` wasn't already imported in runs.ts this won't compile. Also `liveRuns` is exported from runs.ts and imported by work.ts and dashboard.ts — check for circular import (work.ts already imports from runs.ts elsewhere, so likely fine, but dashboard.ts importing liveRuns from runs.ts which may import from dashboard is worth verifying).

### c12-F013
file: apps/server/src/services/work.ts  line: 232  severity: low
`workingAgents` counts `r.agentId` including nulls (leftJoin on agents). A run with a deleted/missing agent contributes a null to the Set, inflating the count by one and never matching any real agent. Should filter nulls or count distinct non-null agentIds.

### c12-F014
file: apps/server/src/services/work.ts  line: 199  severity: high
onCard logic is wrong: `(r.purpose !== "chat" || r.ticketId === id) || r.runTicketId === id`. For a chat run (purpose === "chat") with ticketId === id, the first clause is false but the second clause `r.ticketId === id` is true, so chat runs DO count on their own ticket — contradicting the comment "chat runs don't count". The old code excluded chat runs entirely via `or(isNull(purpose), ne(purpose, "chat"))`. A chat run on a ticket will now show as working on that card.

### c12-F015
file: apps/server/src/services/work.ts  line: 199  severity: high
onCard also matches non-chat runs whose ticketId is null against any card via `r.runTicketId === id` — that's intended — but for a non-chat run with ticketId set to a ticket NOT on this board, `r.purpose !== "chat"` is true so onCard returns true for every id, meaning the run is considered 'shown on a card' for every card even though no card actually displays it. Combined with withoutCard's `!ids.some(...)`, such runs are dropped from the strip entirely.

### c12-F016
file: apps/server/src/services/work.ts  line: 202  severity: high
withoutCard uses `!ids.some((id) => onCard(r, id))` where `ids` are only the tickets on THIS board. A run on a ticket in another project (or a ticket filtered out of this board) will have onCard true for that id only if the id is in `ids`; since it isn't, onCard is false for all ids and the run appears in withoutTicket — but the run DOES have a ticket, so it's mislabeled as 'Working without a ticket'. Conversely, because of the onCard bug above, non-chat runs with any ticketId are treated as on-card for every id, so they never appear in the strip even when their ticket isn't on this board.

### c12-F017
file: apps/server/src/services/work.ts  line: 226  severity: medium
`workingAgents: new Set(everyLive.map((r) => r.agentId)).size` counts distinct agentId including null. A run with no agent (agentId null) contributes 1 to the count, and multiple null-agent runs collapse to 1. The dashboard's `stats.running` likely counts runs (or non-null agents) differently, so the test's `expect(board.workingAgents).toBe(dash.stats.running)` can pass by coincidence but the two figures are not actually the same metric. Filter out null agentIds or align with the dashboard's definition.

### c12-F018
file: apps/server/src/services/dashboard.ts  line: 81  severity: medium
Dashboard now uses liveRuns which joins agents and tickets and runs three correlated subqueries per row (originFrom, originNote, wakeNote). The previous query was a single-column select. This is a heavier query on the hot dashboard path; also the dashboard only needs agentId, so the extra joins/subqueries are wasted work. Not a correctness bug but a real regression in query cost on the home screen.

### c12-F019
file: apps/web/src/pages/Board.tsx  line: 590  severity: medium
`<RunLabelLink run={{ ...r, note: r.wakeNote }} />` spreads UnticketedRun into RunLabelLink's expected run shape. UnticketedRun has `origin`, `originFrom`, `originNote`, `wakeNote`, `runTicketId` but RunLabelLink likely expects a different shape (e.g. `note`, `origin`, `originFrom`). Passing `note: r.wakeNote` overrides any `note` field but the spread also carries `wakeNote` which may be unexpected. Verify RunLabelLink's prop type; if it expects a `Run` with required fields not present here, this is a type error or renders wrong labels.

### c12-F020
file: apps/web/src/pages/Board.tsx  line: 590  severity: low
The strip renders `r.agent ?? "An agent"` as plain text (good, escaped by React), but `RunLabelLink` may render `originNote`/`wakeNote` as HTML or via dangerouslySetInnerHTML. The test only checks that an `<img>` isn't rendered from `wakeNote`; it doesn't verify `originNote` is escaped. Confirm RunLabelLink escapes all agent-written fields.

### c12-F021
file: apps/server/src/services/work.ts  line: 218  severity: low
`working: [...new Set(everyLive.filter((l) => onCard(l, t.id)).map((l) => l.agent ?? "An agent"))]` dedupes by agent name, not agentId. Two different agents with the same name collapse to one entry; conversely the same agent with a null name and a named run shows as both "An agent" and the name. Dedupe by agentId and map to name.

### c12-F022
file: apps/server/src/services/work.ts  line: 220  severity: low
`workingSince` recomputes `everyLive.filter((l) => onCard(l, t.id))` a second time per card (also done for `working` above). With N cards and M live runs this is O(N*M) with the buggy onCard predicate; not a correctness issue but wasteful and easy to get out of sync. Compute the per-card live list once.

### c12-F023
file: apps/server/test/run-origin.test.ts  line: 108  severity: low
The test asserts `board.workingAgents === dash.stats.running` but the two are computed by different code paths (board: distinct agentId from liveRuns; dashboard: whatever stats.running is). If stats.running counts runs rather than agents, this test passes only because the fixture has one run per agent. It doesn't actually verify the two metrics agree in general, so it won't catch the null-agentId or multi-run-per-agent divergence.
