# Change c15 (merge commit 0d1ca84) — CLEAN CONTROL (nothing seeded)
Diff the models saw: /tmp/bakeoff/diffs/c15.diff

## Findings (anonymous ids)

### c15-F001
file: apps/web/src/pages/Board.tsx  line: 47  severity: low
workingFor() relies on age(), which uses Math.round(), so a run that has been active for 30–59 seconds is displayed as "1m" rather than "now" as the function's comment promises.

### c15-F002
file: apps/web/src/pages/Board.tsx  line: 47  severity: low
workingFor delegates to age(), which rounds elapsed minutes. A run that is 30–59 seconds old is therefore displayed as "1m" rather than "now", despite the function's comment and the first-minute requirement. Only runs under 30 seconds currently show "now".

### c15-F003
file: apps/web/src/pages/Board.tsx  line: 44  severity: medium
workingFor() returns "now" when workingSince is missing, so a card with a live run but no startedAt (older server, or a run row with null startedAt) shows "now" indefinitely instead of falling back to age(lastActivityAt). The footer condition `t.working?.length ? workingFor(t.workingSince) : age(...)` never falls back.

### c15-F004
file: apps/server/src/services/work.ts  line: 220  severity: low
workingSince re-filters the entire `live` array for every card (O(cards × live)); the same filter is already computed for `working` on the line above. Compute once per ticket.

### c15-F005
file: apps/web/src/styles.css  line: 682  severity: medium
Sticky side menu uses height: 100vh with overflow-y: auto. On mobile browsers with dynamic toolbars 100vh exceeds the visible viewport, so the bottom of the menu (and its own scroll) is clipped. Use 100dvh or max-height: 100vh with min-height: 0.

### c15-F006
file: apps/web/src/pages/Board.tsx  line: 411  severity: low
featureFilter falls back to "any" when the saved feature isn't in featureList, but featureList is empty until the features poll resolves. On first paint the select shows the stale saved id (not in options) and the filter is applied as "any" only after features load, causing a visible flicker and a brief mismatch between the select value and the applied filter.

### c15-F007
file: apps/web/test/board-filters.test.tsx  line: 100  severity: low
The 'remembers both choices' test calls cleanup() then open() without re-stubbing fetch; it relies on the previous stub still being installed. If a future test adds vi.unstubAllGlobals or reorders, this silently breaks. Also it doesn't assert the feature select value is restored, only the resulting cards.

### c15-F008
file: apps/server/src/services/work.ts  line: 218  severity: medium
workingSince calls .getTime() on runs.startedAt without a null guard; if the column is nullable this throws at runtime for any live run with a null start time.

### c15-F009
file: apps/web/src/pages/Board.tsx  line: 411  severity: medium
featureFilter falls back to "any" when the saved feature isn't in featureList, but the persisted filters.feature is left unchanged; once the feature list loads (or on remount) the stale id can silently reactivate, so the displayed filter and stored filter disagree.

### c15-F010
file: apps/web/src/pages/Board.tsx  line: 411  severity: low
featureList is empty on first render (features are polled), so a valid saved feature briefly renders as "any" and the board shows all tickets before snapping to the filtered set.

### c15-F011
file: apps/web/src/pages/Board.tsx  line: 396  severity: low
setFilter performs a sessionStorage write inside the useState updater; React may invoke the updater twice (StrictMode) and side effects in reducers are discouraged, though the write is idempotent.

### c15-F012
file: apps/web/src/styles.css  line: 682  severity: low
Sticky nav relies on `.app > nav.side` being a direct child and `.app` being a flex container with stretch alignment; if either assumption is wrong the sticky/align-self rules are no-ops. Also height:100vh ignores dynamic mobile toolbars (mitigated by the 840px breakpoint).

### c15-F013
file: apps/web/test/board-filters.test.tsx  line: 30  severity: low
The fetch stub returns json([]) for any unmatched URL; if Board calls another endpoint expecting an object (e.g. company detail) the test would throw rather than fail meaningfully, and it silently masks missing-endpoint coverage.
