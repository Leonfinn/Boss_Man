# Change c09 (merge commit 220054b) — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c09.diff

ANSWER KEY: file apps/server/src/services/sweeps.ts, line ~41 (line in the new file), type: wrong operator / boundary
Bug: The sweep's merge-retry delay is the check timeout MINUS 5 minutes instead of plus, so a check that is still running is mistaken for a stopped one and a second landing can start.

## Findings (anonymous ids)

### c09-F001
file: apps/server/src/services/sweeps.ts  line: 300  severity: medium
The sweep selects stale approved tickets without atomically claiming them. A concurrent landOnce can start and touch the ticket after this SELECT but before retryLand is called; the sweep will still retry the already-selected ticket, causing duplicate checks/merges. The heartbeat in review.ts does not prevent this race because it is not a lock or lease and the sweep does not re-check activity atomically before retrying.

### c09-F002
file: apps/server/src/services/sweeps.ts  line: 300  severity: medium
The sweep selects approved tickets solely from a lastActivityAt snapshot and then calls retryLand without atomically claiming the ticket or rechecking its activity state. If the sweep's SELECT runs just before the in-flight landOnce heartbeat updates lastActivityAt, it can still select the ticket and start a second landing. The heartbeat reduces this race window but does not eliminate it; the sweep needs an atomic claim/state transition or a recheck before retrying.

### c09-F003
file: apps/server/src/services/sweeps.ts  line: 30  severity: high
mergeMissedAfterMs is derived from VERIFY_ASK_TIMEOUT_MS, but the merge/push ask uses MERGE_WAIT_MS (10 min) and can queue behind other work. A ticket whose verify finished and whose merge is still running (or queued) for up to MERGE_WAIT_MS after the last heartbeat can still be swept and retried. The threshold should be at least max(VERIFY_ASK_TIMEOUT_MS, MERGE_WAIT_MS) plus a margin, or the heartbeat must cover the whole landOnce body.

### c09-F004
file: apps/server/src/services/review.ts  line: 452  severity: high
whileActive only wraps the individual ask() calls. Between asks (e.g. after the last verify returns and before the merge ask starts, or during prTarget()/templates() DB calls) there is no heartbeat, and the initial touch() is the only activity. If the sweep runs in that window with a stale lastActivityAt (e.g. the verify just returned after 25 min but the ticket was already stale before landOnce started), it can still start a second landing. The heartbeat should span the whole landOnce body, not just each ask.

### c09-F005
file: apps/server/src/services/review.ts  line: 449  severity: medium
The heartbeat fires every MERGE_ACTIVITY_MS (60s) via setInterval. If the sweep's threshold is close to the verify timeout and the sweep runs just before a tick, the ticket can appear stale by up to MERGE_ACTIVITY_MS. Combined with the derived threshold (VERIFY_ASK_TIMEOUT_MS - 5min), the safety margin is only 5 min minus up to 60s of jitter — thin for a 30-min check. Consider touching synchronously before each ask (already done) plus a shorter interval, or making the sweep threshold strictly greater than VERIFY_ASK_TIMEOUT_MS + MERGE_ACTIVITY_MS.

### c09-F006
file: apps/server/src/services/review.ts  line: 449  severity: medium
touch() failures are swallowed (`.catch(() => undefined)`). If the DB write fails repeatedly (e.g. connection blip), the heartbeat silently stops updating lastActivityAt and the sweep can retry the merge while the original is still running — exactly the bug this change is meant to prevent. At minimum log the failure; ideally surface it or abort the landing.

### c09-F007
file: apps/server/test/review-policy.test.ts  line: 240  severity: low
The test fakes only setInterval/clearInterval and then calls vi.useRealTimers() before release(). If the heartbeat interval was scheduled under fake timers and the test releases before advancing past the next tick, the interval may never fire under real timers (or fire immediately), making the test flaky and not actually exercising the heartbeat across the sweep. Also, the test asserts lastActivityAt is fresh only after advancing timers — it doesn't verify the heartbeat keeps firing across multiple intervals.

### c09-F008
file: apps/server/src/services/sweeps.ts  line: 41  severity: high
mergeMissedAfterMs is set to VERIFY_ASK_TIMEOUT_MS - 5min, but landOnce can spend up to VERIFY_ASK_TIMEOUT_MS on the shallow check PLUS VERIFY_ASK_TIMEOUT_MS on the deep check (high/critical risk) PLUS MERGE_WAIT_MS on the merge, plus the diff ask. A high-risk ticket whose shallow check runs long and then whose deep check also runs long will exceed the sweep threshold even with the 60s heartbeat, because the heartbeat only refreshes lastActivityAt while a single ask is in flight — the sweep can fire between the two checks or during the merge. The threshold should be derived from the total worst-case landing duration (diff + N*verify + merge), not a single verify timeout.

### c09-F009
file: apps/server/src/services/review.ts  line: 449  severity: medium
The heartbeat only runs inside whileActive() around individual asks. Between the diff ask and the first verify ask, between the two verify asks, and around the prTarget() call and the sendBack() paths, no heartbeat runs. If any of those gaps (or the DB round-trip inside touch()) is slow, lastActivityAt can go stale long enough for the sweep to fire mid-landing — exactly the bug this change is meant to fix. The heartbeat should wrap the whole landOnce body, not each ask.

### c09-F010
file: apps/server/src/services/review.ts  line: 448  severity: medium
touch() inside the interval is fire-and-forget (`void touch().catch(...)`). If the DB write is slow or fails silently, lastActivityAt is not actually refreshed, but the code proceeds as if it were. There is no way for the caller to know the heartbeat is failing, and a persistent DB error would silently reintroduce the double-landing race. At minimum the failure should be logged; ideally the interval should await the previous touch before scheduling the next.

### c09-F011
file: apps/server/test/review-policy.test.ts  line: 246  severity: medium
The test fakes only setInterval/clearInterval, then asserts `Date.now() - lastActivityAt < MERGE_ACTIVITY_MS` after advancing timers. But the initial `await touch()` at the top of landOnce already set lastActivityAt to ~now, so this assertion passes whether or not the interval fired. The test does not actually prove the heartbeat works — it would pass even if whileActive were removed. The test should set lastActivityAt to an old value AFTER the initial touch (e.g. via a spy on the interval callback, or by asserting the DB was written a second time), or check that lastActivityAt advanced past the value set by the initial touch.

### c09-F012
file: apps/server/test/review-policy.test.ts  line: 232  severity: low
The first new test ('keeps the ticket active so the sweep doesn't start a second landing beside it') does not fake timers and does not advance time, so the 60s heartbeat never fires during the test. It only proves that the initial `await touch()` at the top of landOnce keeps the ticket fresh — which was already true before this change. The test does not exercise the new heartbeat code path at all.

### c09-F013
file: apps/server/src/services/sweeps.ts  line: 41  severity: low
VERIFY_ASK_TIMEOUT_MS - 5 * 60_000 is a magic derivation with no guard. If VERIFY_ASK_TIMEOUT_MS is ever lowered below 5 minutes (or set to 0 in a test), mergeMissedAfterMs becomes zero or negative, and the sweep will fire immediately on every approved ticket. A Math.max(..., someFloor) or an explicit constant would be safer.
