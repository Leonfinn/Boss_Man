# Change c03 (merge commit df18ae1) — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c03.diff

ANSWER KEY: file apps/server/src/services/decisions.ts, line ~697 (line in the new file), type: wrong condition (security: allow-list bypass)
Bug: The allow-list of tool-input keys now passes when ANY key is a Bash key instead of ALL, so a command carrying an extra key like workdir/cwd is treated as running in the working copy.

## Findings (anonymous ids)

### c03-F001
file: apps/server/src/services/decisions.ts  line: 686  severity: high
The allow-list check uses `Object.keys(raw).some(k => SHELL_INPUT_KEYS.has(k))` instead of requiring every key to be allowed. A request such as `{ command: "rm -rf dist", cwd: "/home/node" }` therefore passes the check, and the server treats the delete as being in the reported working copy even though the shell may execute it elsewhere. This bypasses the intended protection for unknown cwd/workdir fields and can send an unsafe delete to the CEO as a working-copy cleanup.

### c03-F002
file: packages/shared/src/policy.ts  line: 43  severity: high
The WORKING_COPY_RULE requires commandPattern: DESTRUCTIVE, whose rm matcher requires an r or f flag. Thus commands such as `rm src`, `rmdir src`, `unlink src`, and `rm -d src` never match the working-copy rule even though cleanupScope recognizes them; they then fall through to the default `Other shell commands` allow rule. These commands can delete working-copy files without going to the CEO or owner. Match the cleanup scope directly or ensure every supported delete form is covered by the destructive predicate.

### c03-F003
file: packages/shared/src/policy.ts  line: 120  severity: medium
The final match result does not include `rule.workingCopyOnly`. A rule whose match contains only workingCopyOnly therefore returns false even when its working-copy predicate succeeds. Include workingCopyOnly in this Boolean check (and, for consistency, the existing tempCleanupOnly predicate).

### c03-F004
file: apps/server/src/services/decisions.ts  line: 700  severity: high
The allow-list check `Object.keys(raw).some((k) => SHELL_INPUT_KEYS.has(k))` passes if ANY known key is present, not if ALL keys are known. An input like `{command: 'rm -rf dist', workdir: '/etc'}` (or `cwd`, `folder`, etc.) still routes to the CEO with a working-copy card, even though the extra key could point the shell elsewhere. The test only covers inputs with no known keys. Should be `Object.keys(raw).every((k) => SHELL_INPUT_KEYS.has(k))`.

### c03-F005
file: apps/server/src/services/decisions.ts  line: 690  severity: high
The worktree is trusted from any `run.workspace` event matching `runId` and `ticketId`, but the runner's actual cwd for the shell is never verified. The comment says 'the runner reported it started this run in its ticket's own worktree', but the query only checks that such an event exists — a later `run.workspace` for the same run (e.g. a review copy, or a re-created worktree at a different path) is not distinguished, and the branch is taken from the latest event regardless of whether it matches the run's current state. A stale or superseded workspace event still authorizes CEO routing.

### c03-F006
file: packages/shared/src/explain.ts  line: 220  severity: high
`DELETE` regex is looser than `TEMP_DELETE`: it accepts any non-whitespace, non-`>&` token as a path, then `deletePaths` filters with `TEMP_ONLY.test(p) || inWorkingCopy(p)`. But `TEMP_ONLY` is not shown here and `inWorkingCopy` allows paths like `a.gitignore` (fine) but also `..foo` (leading dot then dot — `WORKING_PATH` allows `..foo` since first char is `.` and rest is `[A-Za-z0-9._+@-]`), and `a/..b` (part `..b` is not `..` so passes). More importantly, `DELETE` allows flags like `--files0-from=list` to be parsed as flags (the flag group `--?[A-Za-z][A-Za-z-]*` matches `--files0-from`? No — `0` isn't in `[A-Za-z-]`, so it fails and the whole segment is rejected; good). But `rm -rf -x` — `-x` matches the flag group, then no paths, so `paths` is undefined and `deletePaths` returns null; the test expects this to be rejected, which it is. The real gap: `DELETE` accepts `rm -rf dist/` (trailing slash) and `inWorkingCopy` strips it, but `DELETE` also accepts `rm -rf dist//` (double slash) — `WORKING_PATH` allows `dist//`? No, `(?:/[A-Za-z0-9._+@-]+)*/?` requires non-empty segment after each `/`, so `dist//` fails. OK. The actual concern: `DELETE` matches `rm -rf dist` where `dist` is a symlink to `/etc` — the code acknowledges this and relies on the CEO, but the recommended verdict for `dist` is Allow, so the CEO is nudged to approve a symlink-following delete.

### c03-F007
file: packages/shared/src/explain.ts  line: 240  severity: medium
`inWorkingCopy` allows paths whose first segment starts with `.` (e.g. `.env`, `.github/workflows`). The test asserts `.env` is Deny via `recommendedVerdict`, but `cleanupScope` still returns it as a working-copy path, so it routes to the CEO with a working-copy card. That's arguably intended, but the CEO wake text says 'It recommends Allow only for build output' — yet `.env` is a working-copy path and the recommended verdict is Deny, so the CEO sees a Deny-recommended card. Not a bug per se, but the routing of `.env`/`.github` to the CEO (rather than owner) is a policy change not called out in the ticket.

### c03-F008
file: apps/server/src/services/decisions.ts  line: 745  severity: medium
`recommendedOption: recommendedVerdict(info) === 'allow' ? ALLOW : DENY` changes behavior for the existing TEMP_CLEANUP path too: previously `recommendedVerdict(info) === 'deny' ? DENY : ALLOW`, so a temp cleanup with an unknown verdict (neither allow nor deny) defaulted to Allow; now it defaults to Deny. The test `expect((await ctx.ask(CLEANUP)).d).toMatchObject({ tier: 'owner', recommendedOption: 'Allow once' })` still passes because `recommendedVerdict` returns 'allow' for that command, but any temp cleanup where `recommendedVerdict` returns something other than 'allow'/'deny' (e.g. 'unknown') now flips to Deny. This is a silent behavior change for BOS-111.

### c03-F009
file: apps/server/src/services/decisions.ts  line: 760  severity: medium
When the CEO is paused, `tier` falls to 'owner' but `workingCopy` is still set, so the context has `workingCopy` and no `ladder`. The card question says 'WORKING-COPY CLEANUP' and the CEO wake text is skipped (correct), but the owner now sees a card whose `recommendedOption` is Deny for build output (because `recommendedVerdict` for `rm -rf dist` is 'allow' → ALLOW, so actually Allow — OK). However, the test comment says 'Build output alone keeps BOS-111's Allow recommendation, but still reaches the owner without a checkout' — that's for the no-checkout case, not the paused-CEO case. The paused-CEO case with `rm -rf dist` would get Allow, which is fine, but the paused-CEO case with `rm -rf src` gets Deny — also fine. No bug, but the interaction is untested for the paused-CEO + build-output case.

### c03-F010
file: packages/shared/src/policy.ts  line: 110  severity: medium
`matches` for `workingCopyOnly` checks `cleanupScope(cmd)?.workingCopy.length`, but `cleanupScope` returns non-null for a command that is *only* temp deletes (workingCopy empty) — that's correctly rejected. However, `cleanupScope` also returns non-null for a command with working-copy deletes AND a `cd` — no, `cd` is rejected. The real issue: `cleanupScope` returns non-null for `rm -rf dist && mkdir /tmp/x` (working-copy delete + /tmp write), which routes to the CEO via WORKING_COPY_RULE. The CEO wake text says 'Any other deletes are of entries directly in /tmp' — but there are no /tmp deletes here, only a /tmp write. The text is misleading but not a security bug. More concerning: `cleanupScope` returns non-null for `rm -rf dist && git worktree add -b x /tmp/lnk`? The test says this is rejected — let me check: `git worktree add` is not in `safeBeside`'s allow-list (it's a write to /tmp/lnk which isn't cleared), so `safeBeside` returns false and `cleanupScope` returns null. Good.

### c03-F011
file: packages/shared/src/explain.ts  line: 260  severity: medium
`cleanupScope` clears `/tmp` entries only when `TEMP_DELETE.test(s)` is true, but the `cleared` set is populated from `words.slice(1)` of the segment — which includes flags like `-rf`. `CLEARING_FLAG.test(w)` presumably filters those, but the code adds `w` to `cleared` for any `TEMP_ONLY.test(w)` word, including the command name `rm` if it happened to match (it doesn't). More importantly, `cleared` is populated even when the segment is `rm -rf /tmp/x` but the segment is NOT chained (`chained` is false) — the code checks `if (chained && ...)`, so that's guarded. OK.

### c03-F012
file: apps/server/src/services/decisions.ts  line: 700  severity: medium
The `run.workspace` query filters by `runId` and `ticketId` but not by `runnerId` matching the run's runner — actually it does filter `eq(runnerEvents.runnerId, runner.id)`, so that's fine. But it orders by `desc(runnerEvents.seq)` and takes the latest — if a run reports multiple workspaces (e.g. a review copy after the main worktree), the latest wins, which may not be the one the shell is in. The comment claims 'the runner reported it started this run in its ticket's own worktree' but the query doesn't verify the event is a `run.started`-adjacent workspace or that no later workspace superseded it.

### c03-F013
file: apps/server/src/services/decisions.ts  line: 690  severity: low
`const raw = (event.rawInput ?? {}) as Record<string, unknown>` — if `rawInput` is an array or a primitive, `Object.keys` behaves unexpectedly (arrays give indices, primitives give `[]`). An array `['rm', '-rf', 'dist']` would have keys `['0','1','2']`, none in `SHELL_INPUT_KEYS`, so `files` is `[]` and the request falls to owner — correct. But a string `rawInput` would give `Object.keys('abc')` = `['0','1','2']` — also falls to owner. OK, but the cast is unsafe; a non-object `rawInput` with a `command` property can't exist, so this is defensive only.

### c03-F014
file: apps/server/src/services/decisions.ts  line: 745  severity: low
The question text appends `In ${agent?.name ?? 'the agent'}'s working copy for ${workingCopy.ref ?? 'its ticket'} (branch ${workingCopy.branch}): ${fileList(workingCopy.files, 400)}.` — `workingCopy.branch` comes from the runner event and is not sanitized. A branch name containing newlines or control characters would be injected into the decision question, which is shown to the CEO and owner. Branch names can contain `/`, `-`, `.`, but git allows some unusual characters; more importantly, the runner is trusted, but a compromised runner could inject text. Low severity since the runner is trusted.

### c03-F015
file: apps/server/src/services/decisions.ts  line: 760  severity: low
The CEO wake note for working-copy cleanup says 'It has no cd.' — but `cleanupScope` rejects any command with `cd`, so this is accurate. However, the note also says 'Any other deletes are of entries directly in /tmp' — but a command like `rm -rf dist && mkdir /tmp/x` has no /tmp deletes, only a /tmp write. The note is misleading. Also, the note says 'Boss Man can't see the runner's files: if a folder on one of those paths is a symlink, the delete follows it out of the checkout' — accurate, but the recommended verdict for `dist` is Allow, so the CEO is nudged to approve a potentially symlink-following delete.

### c03-F016
file: packages/shared/src/explain.ts  line: 220  severity: low
`DELETE` regex allows `rm -rf -- dist` (the `--` flag), and `deletePaths` extracts `dist` — good. But it also allows `rm -rf -- -x` where `-x` is treated as a path (since `--` ends flag parsing), and `inWorkingCopy('-x')` fails (leading `-`), so `deletePaths` returns null — correct. However, `rm -rf -- --files0-from=list dist` — `--files0-from=list` is treated as a path, `inWorkingCopy` fails (contains `=`), so rejected — correct. The regex is reasonably tight.

### c03-F017
file: packages/shared/src/explain.ts  line: 240  severity: low
`inWorkingCopy` allows paths like `a/b/../c`? No — `WORKING_PATH` disallows `..` as a segment, and the `every` check also rejects `..`. But `WORKING_PATH` allows `a/..b/c` (segment `..b` is not `..`), which is a valid filename but could be confusing. Not a security issue.

### c03-F018
file: apps/server/test/temp-cleanup.test.ts  line: 200  severity: low
The test `expect((await ctx.ask('rm -rf dist')).d).toMatchObject({ tier: 'owner', recommendedOption: 'Allow once' })` — this is the no-checkout case. But the test comment says 'Build output alone keeps BOS-111's Allow recommendation' — BOS-111's temp cleanup would route `rm -rf dist` to the CEO (since `dist` is not in /tmp, it's not a temp cleanup). So this is actually the WORKING_COPY_RULE matching but falling to owner due to no checkout. The comment is misleading but the test is correct.

### c03-F019
file: apps/server/test/temp-cleanup.test.ts  line: 220  severity: low
The test `for (const c of ['rm -rf ../other', 'rm -rf .git', 'cd src && rm -rf x', ...])` expects `tier: 'owner'` — but `rm -rf ../other` and `rm -rf .git` are rejected by `cleanupScope` (return null), so they don't match WORKING_COPY_RULE and fall to the default 'Destructive commands go to the owner' rule. Correct. But `rm -rf dist; cp -r src /tmp/x` — `cleanupScope` returns null (cp not in safeBeside), so falls to owner. Correct.

### c03-F020
file: apps/web/src/pages/Rules.tsx  line: 30  severity: low
`describeMatch` adds `workingCopyOnly` description, but the Rules page has no UI to toggle `workingCopyOnly` — it's only set by the default policy. The `Match` type now includes it, but no form control creates it. Not a bug, but the description is dead code for user-created rules.

### c03-F021
file: apps/server/src/services/decisions.ts  line: 730  severity: medium
When the CEO is paused (or absent), tier falls back to "owner" but `workingCopy` is still set and stored in context, so the owner's card and the audit record say "working-copy cleanup" even though the CEO never saw it. The wake note is also skipped (the `if (row && ceoId && wake)` branch is not taken), so the owner gets no explanation of why this is a working-copy delete. Either clear `workingCopy` on fallback or make the owner-facing text explicit that the CEO was unavailable.

### c03-F022
file: packages/shared/src/explain.ts  line: 219  severity: medium
`DELETE` matches `rm` with no flags at all (the flag group is `*`), so `rm file` in a checkout now matches `workingCopyOnly` and routes to the CEO. That's a behavior change for a non-destructive-looking command that previously fell through to "Other shell commands" (allow). The `DESTRUCTIVE` commandPattern on the rule still requires `-r`/`-f`, so the rule only fires when the command also matches DESTRUCTIVE — but the `DELETE` regex itself accepting flagless `rm` means `cleanupScope` returns a non-null scope for `rm a && rm -rf b`, which then routes to the CEO on the strength of the `-rf` on `b` while `a` is silently included in the file list. Tighten `DELETE` to require at least one flag, or document that flagless `rm` is intentionally in scope.

### c03-F023
file: apps/server/src/services/decisions.ts  line: 262  severity: low
`fileList` returns an empty string when the first file name alone exceeds `max` (the loop breaks before appending anything, and `shown` stays 0, so the suffix is `…and N more` with no leading name). The card then reads `... (branch X): …and N more.` with a dangling colon. Guard against `out === ""` by always including at least the first file (truncated) or emitting a placeholder.

### c03-F024
file: apps/server/src/services/decisions.ts  line: 700  severity: low
The `SHELL_INPUT_KEYS` allow-list is checked with `Object.keys(raw).some(...)`, so a raw input containing only `{ command: "..." }` passes, but so does one containing `{ command: "...", description: "..." }` — fine — and one containing `{ command: "...", cwd: "/etc" }` fails as intended. However, the check is `some` not `every`: an input with `{ command, description, cwd }` fails (good), but an input with `{ command, description }` passes even though `description` is not a key that moves the shell. That's the intent, but the comment says "None of them moves the shell to another folder" — the check should be `every(k => SHELL_INPUT_KEYS.has(k))` to match the comment and reject any unknown key, not just require at least one known key. As written, `{ command, cwd }` is rejected (cwd not in set) but `{ command, description, cwd }` is also rejected — so the `some` is actually equivalent to `every` here only because `command` is always present. Still, `every` is clearer and safer if `command` is ever absent.

### c03-F025
file: packages/shared/src/explain.ts  line: 219  severity: low
`DELETE`'s path group `((?:\s+[^\s>&]+)+)` accepts paths containing `;`, `|`, `&`, `(`, `)`, `$`, backtick, quotes, etc. — anything except whitespace, `>`, `&`. Combined with `PLAIN.test(command)` at the top of `cleanupScope`, most of these are rejected, but `;` and `|` are not in `PLAIN`'s exclusion set in the same way — verify `PLAIN` rejects `;` and `|` inside a path. If `PLAIN` allows `;`, then `rm -rf a;b` would parse `a;b` as a single path and `inWorkingCopy` would reject it (since `;` isn't in `WORKING_PATH`), so it's safe — but the regex is looser than the comment suggests. Consider tightening `DELETE`'s path class to `[A-Za-z0-9._+@/-]+` to match `WORKING_PATH` and `TEMP_PATH`.
