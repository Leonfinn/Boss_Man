# Change c11 (merge commit 65af64f) — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c11.diff

ANSWER KEY: file apps/server/src/services/review-policy.ts, line ~83 (line in the new file), type: missing permission / authorisation check
Bug: The hand-over pool no longer excludes the ticket's author, so a review can be moved to the agent who wrote the change.

## Findings (anonymous ids)

### c11-F001
file: apps/server/src/services/review-policy.ts  line: 76  severity: high
The `author` parameter is never used when selecting replacement reviewers. As a result, handOverReviews can assign a review to the ticket's author, even though the function's own contract says the author must never review their own ticket. This can invalidate the review and compromise review independence.

### c11-F002
file: apps/server/src/services/review-kinds.ts  line: 146  severity: medium
If a ticket has multiple pending reviews and only some can be handed over, the original ticket block is retained in the old wake while wakeReviewers creates another wake for the moved requests. The old wake therefore still contains the same ticket and can cause the moved review to be started or handled again, producing duplicate review work and potentially conflicting reviewer state.

### c11-F003
file: apps/server/src/services/review-policy.ts  line: 78  severity: high
otherReviewers accepts an `author` argument but never excludes that agent from the candidate pool. A ticket author who is also a senior developer or marked reviewer can therefore be handed a review of their own ticket, undermining the author-exclusion rule and the existing resolveKindReviewer behavior.

### c11-F004
file: apps/server/src/services/review-kinds.ts  line: 157  severity: medium
When only some of the current reviewer's requests are handed over, the original wake block is retained because `moved.length < mine.length`. That block still refers to the moved review, so the old reviewer continues to hold a wake for work that was reassigned. Conversely, when `mine` is empty, the block is also retained, leaving stale wake blocks indefinitely. The wake note needs to be rewritten per review/block rather than retaining the whole block.

### c11-F005
file: apps/server/src/services/scheduler.ts  line: 966  severity: medium
The `isBusy` callback checks only `byAgent`, which reflects wakes handled in the current scheduler pass, not whether the candidate already has an active run. A reviewer with an existing run but no pending wake can be selected as a replacement, so the review is reassigned to another busy reviewer instead of a free one. Candidate availability should be determined from active runs (and the scheduler's current wake load).

### c11-F006
file: apps/server/src/services/review-kinds.ts  line: 118  severity: high
handOverReviews reassigns a review to another reviewer without checking whether that reviewer already holds a review for the same ticket/round, so a ticket can end up with two reviews assigned to the same agent (or the same agent reviewing twice).

### c11-F007
file: apps/server/src/services/review-kinds.ts  line: 118  severity: high
otherReviewers is called with t.assigneeAgentId as the author, but the review's author is the ticket's original author, not necessarily the current assignee; a handover can move a review to the ticket's author, defeating the point of review.

### c11-F008
file: apps/server/src/services/review-kinds.ts  line: 100  severity: medium
reviewWaits runs a per-ticket loop of 3+ queries (agents, runs, wakes) and is called from listReviews (per ticket page) and from workService board listing (per board), producing an N+1 explosion on the board endpoint.

### c11-F009
file: apps/server/src/services/review-kinds.ts  line: 130  severity: medium
The wakes lookup uses like(wakes.note, `%- ${ticketId} %`) which requires a trailing space after the id; a note whose last block ends with the ticket id (no trailing space) won't match, so the 'waiting on' line is silently omitted.

### c11-F010
file: apps/server/src/services/review-kinds.ts  line: 108  severity: medium
handOverReviews splits the note with /^(?=- [0-9a-f-]{36} )/m; if the note format ever changes or a block lacks the leading '- <uuid> ' prefix, the block is dropped from `kept` and the wake loses content silently.

### c11-F011
file: apps/server/src/services/review-kinds.ts  line: 108  severity: medium
handOverReviews does not re-check that the ticket is still in review after the async lookups; a ticket that left review between the wake being queued and the handover runs will still have its review reassigned and a handover activity logged.

### c11-F012
file: apps/server/src/services/review-kinds.ts  line: 108  severity: medium
handOverReviews only moves reviews whose reviewerAgentId === wake.agentId; if the wake's agent has already been reassigned (e.g. by a prior handover), the block is kept but no review moves, and the wake is never dropped — it can loop forever.

### c11-F013
file: apps/server/src/services/scheduler.ts  line: 966  severity: medium
The handover branch only fires when (byAgent.get(w.agentId) ?? 0) >= limits.agent; a reviewer busy on a chat run (which is tracked separately via `chatting`) may not count toward byAgent, so handover never triggers for that case even though the reviewer is busy.

### c11-F014
file: apps/server/src/services/scheduler.ts  line: 966  severity: medium
After handOverReviews returns a non-null `left`, the wake note is updated but the wake is not re-evaluated for launch in the same tick; the reviewer may still be busy and the wake stays queued with a stale note until the next tick.

### c11-F015
file: apps/server/src/services/review-kinds.ts  line: 96  severity: low
listReviews computes `waiting` once per ticket and applies it to every pending row, so multiple pending reviews on the same ticket all show the same 'waiting on' line even when they wait on different reviewers.

### c11-F016
file: apps/server/src/services/review-kinds.ts  line: 118  severity: low
handOverReviews calls record() with agentId: wake.agentId for the handover log, attributing the action to the busy reviewer rather than the system/CEO; this misattributes activity.

### c11-F017
file: apps/server/src/services/review-policy.ts  line: 76  severity: low
otherReviewers does not exclude the ticket's current assignee when the caller passes a different author; combined with the caller passing t.assigneeAgentId, a reviewer who is also the assignee can be selected.

### c11-F018
file: apps/server/test/review-pickup.test.ts  line: 100  severity: low
The test 'only moves the tickets that have someone to move to' asserts waitingOn matches /^Ada is busy on .*-?\d*/ which is very loose and would pass even if the ticket ref is missing; it doesn't actually verify the handover path for the second ticket.

### c11-F019
file: apps/server/src/services/review-kinds.ts  line: 152  severity: high
In handOverReviews, `if (moved.length < mine.length || !mine.length) kept.push(block)` keeps the block when nothing was moved (moved.length === 0 and mine.length > 0) — but the intent is to drop the block only when the review actually moved. When `mine.length === 0` (no active review rows for this agent on this ticket) the block is kept, which is fine, but when `moved.length === 0 && mine.length > 0` the block is also kept — that's correct. However when `moved.length === mine.length` (all moved) the block is dropped, and when `moved.length < mine.length` it's kept — but the kept block still contains the ticket id, so the next tick will re-attempt handover for the already-moved reviews (they're no longer `mine`, so `mine` shrinks and eventually the block is dropped). The real bug: when `mine.length === 0` the block is kept forever, so a wake whose reviews were all moved by a prior tick (or whose reviews were decided) never clears. Also `!mine.length` is redundant with the first clause and keeps blocks that should be dropped.

### c11-F020
file: apps/server/src/services/review-kinds.ts  line: 137  severity: high
The wake lookup uses `like(wakes.note, `%- ${ticketId} %`)` — the note format is `- <ticketId> "Title": ...` (no trailing space after the id before the quote in the test, and the real format may differ). The pattern requires a space after the id, so it will miss wakes whose note is `- <id> "..."` (space then quote is fine) but will also match a ticket id that is a prefix of another id (e.g. `- abc-... ` matching `- abc-...-extra `). More importantly, `like` with `%` and `_` in the id is fine (ids are hex+dashes), but the pattern is anchored only at the start via `%`, so it can match a note that mentions the ticket id in a different block. Use a structured wake→ticket link instead of string matching.

### c11-F021
file: apps/server/src/services/review-kinds.ts  line: 145  severity: medium
`w.reason && w.status === "queued"` — `w.reason` is `wakes.statusReason` selected as `reason`, but the select aliases `wakes.statusReason` to `reason`, so this is the status reason. However the condition `w.reason && w.status === "queued"` means a queued wake with no statusReason falls through to "is about to start", and a deferred wake with a statusReason also falls through to "is about to start" — the deferred case should also surface the reason. The message "is next, but is held up" is only shown for queued wakes, not deferred ones, which is the more common held-up state.

### c11-F022
file: apps/server/src/services/review-kinds.ts  line: 118  severity: medium
`if (live?.ticketId === ticketId) lines.push(`${name} is reviewing it now`)` — `live` is the reviewer's most recent open non-chat run, but the query has no `orderBy`, so `limit(1)` returns an arbitrary open run. If the reviewer has multiple open runs (e.g. one on this ticket and one on another), the result is nondeterministic and may report "busy on X" when they're actually reviewing this ticket. Add `orderBy(desc(runs.startedAt))`.

### c11-F023
file: apps/server/src/services/review-kinds.ts  line: 100  severity: medium
`reviewWaits` runs 3+ queries per active review row per ticket (agent name, live run, wake). `listReviews` calls it for one ticket, but `work.ts` calls it for every in-review ticket on the board — an N×M query storm on every board load. Batch the agent/run/wake lookups across all ticketIds.

### c11-F024
file: apps/server/src/services/review-kinds.ts  line: 148  severity: medium
`handOverReviews` calls `wakeReviewers(db, t, moved, notify)` for the moved reviews, but `moved` contains rows with the new `reviewerAgentId` while the original `reviewRequests` rows were updated in place. If `wakeReviewers` re-reads rows by id it's fine, but if it uses the passed rows' `status`/`round` it may double-notify. More importantly, the old reviewer's wake is only dropped when `left === null`; if some blocks were kept, the old wake remains with a note that still lists the moved ticket (since the block was kept when `moved.length < mine.length`), so the old reviewer will be re-woken for a review they no longer own.

### c11-F025
file: apps/server/src/services/review-policy.ts  line: 78  severity: medium
`otherReviewers` filters `!exclude.includes(a.id)` but does not exclude the ticket's `author` when `ref === SENIOR_DEV` — the doc comment says "never the author" but the filter only excludes `exclude` (which is `[wake.agentId]`). The caller passes `t.assigneeAgentId` as `author` but `otherReviewers` ignores it. A senior dev who authored the ticket can be handed their own review.

### c11-F026
file: apps/server/src/services/scheduler.ts  line: 964  severity: high
The handover only fires when `(byAgent.get(w.agentId) ?? 0) >= limits.agent`. But the reviewer may be "busy" for other reasons — a chat run (excluded from `byAgent`? no, chat runs count), a paused agent (handled earlier), or blocked on a decision. More critically, the condition is inside the `if (total >= limits.instance || ... || (isChat ? ... : (byAgent.get(w.agentId) ?? 0) >= limits.agent))` block, so if the instance or company limit is hit but the agent itself is free, handover never runs — the review stays stuck behind a global limit even though another reviewer could take it. The handover should be evaluated whenever the wake can't launch, not only when the agent is at its own limit.

### c11-F027
file: apps/server/src/services/scheduler.ts  line: 966  severity: medium
`handOverReviews` is called with `(id) => (byAgent.get(id) ?? 0) >= limits.agent` as `isBusy`. This only checks the in-memory `byAgent` map, which is populated from currently-running runs at tick start. An agent with a queued-but-not-yet-launched wake, or one that just finished, may be misclassified. Also `byAgent` counts chat runs, so a reviewer in a chat is considered busy — probably intended, but worth confirming.

### c11-F028
file: apps/server/src/services/scheduler.ts  line: 970  severity: medium
After handover, `if (left !== w.note) await db.update(wakes).set({ note: left }).where(eq(wakes.id, w.id))` — but `w.note` is the in-memory value from the select at the top of the loop, and `handOverReviews` may have already updated the wake's note via `wakeReviewers` (which creates new wakes, not updates this one). If `left` is non-null but equals the original note (no change), the update is skipped — fine. But if `left` is non-null and different, the wake keeps its old `notBefore`/defer, so it may still be deferred past the point where the remaining reviews could launch. Also the wake's `createdAt` is unchanged, so the next tick's `waited` calculation still uses the original time — a wake that has been partially handed over will keep re-triggering handover attempts for the remaining blocks every tick.

### c11-F029
file: apps/server/src/services/work.ts  line: 189  severity: medium
`const waits = await reviewWaits(db, inReview);` — `inReview` is presumably the list of ticket ids in review, but the variable is used before it's defined in the diff context (the diff shows `inReview` referenced but the surrounding code that defines it isn't shown). If `inReview` is not defined in scope this is a compile error; if it is, verify it's the full set of review-state ticket ids and not a subset. Also this adds a per-board-load query storm (see reviewWaits N+1).

### c11-F030
file: apps/server/test/review-pickup.test.ts  line: 118  severity: low
The test `expect(rows[0]!.waitingOn).toMatch(/^Ada is busy on .*-?\d*/)` — the regex `.*-?\d*` is very loose and will match almost anything starting with "Ada is busy on ". It doesn't actually verify the ticket ref is present; the next line `toContain(String(number))` does, but only if `number` is non-null. If `number` is null the test passes vacuously.

### c11-F031
file: apps/server/test/review-pickup.test.ts  line: 60  severity: low
The test `starts a queued review before ordinary work that has waited longer` asserts the review wake launches, but doesn't assert the ordinary `assigned` wake is still queued/deferred — it could have launched too. The test name implies ordering but the assertion only checks the review launched.

### c11-F032
file: apps/web/src/components/TicketReviews.tsx  line: 24  severity: low
`{r.waitingOn && <div ...>{r.waitingOn}</div>}` renders the wait line for every review row including non-pending ones if the server ever sets `waitingOn` on a decided row. The server only sets it for `status === "pending"`, so this is defensive, but the type allows it. Minor.
