# Change c14 (merge commit 7b5b22f) — CLEAN CONTROL (nothing seeded)
Diff the models saw: /tmp/bakeoff/diffs/c14.diff

## Findings (anonymous ids)

### c14-F001
file: apps/server/src/services/alert-ladder.ts  line: 90  severity: high
The outer cap is calculated from `ladder.since`, but `Ladder.since` is documented as the time the card reached its current rung, not the original raise time. For a card that reaches the CEO after waiting on the Scrum Master, this can grant it a fresh 20-minute CEO wait rather than guaranteeing owner handover 20 minutes after the raise.

### c14-F002
file: apps/server/src/services/alert-ladder.ts  line: 90  severity: medium
`Math.max(minutes, CEO_OUTER_CAP_MINUTES)` makes the outer cap 20 minutes only when the configured alert interval is below 20. If `alertMinutes` is configured to 30 or more, the card can wait beyond the stated hard 20-minute cap from the raise. The outer cap should remain fixed at 20 minutes.

### c14-F003
file: apps/server/src/services/alert-ladder.ts  line: 96  severity: high
The query starts the CEO timer for the earliest CEO run after the raise without checking that the run can see this card. It includes runs tied to another ticket and runs that already ended before the card reached the CEO, so such runs can start the five-minute clock and cause premature owner escalation. The run should match the shared/ticketless CEO decision wake and still be able to observe the card.

### c14-F004
file: apps/server/src/services/alert-ladder.ts  line: 93  severity: medium
The outer cap is computed as `raised + Math.max(minutes, CEO_OUTER_CAP_MINUTES)`, so when the configured alert timeout exceeds 20 minutes, cards can wait longer than 20 minutes from the raise. The requirement is a hard 20-minute cap from the raise; the timeout should be bounded by that cap rather than allowed to increase it.

### c14-F005
file: apps/server/src/services/alert-ladder.ts  line: 96  severity: high
The outer cap uses Math.max(minutes, CEO_OUTER_CAP_MINUTES), so a company with alertMinutes > 20 gets a cap larger than 20 minutes. The ticket says the card is capped at 20 minutes from the raise; this silently ignores that cap for any setting above 20.

### c14-F006
file: apps/server/src/services/alert-ladder.ts  line: 96  severity: medium
When no CEO agent exists, dueAt returns raised + minutes, bypassing the 20-minute outer cap entirely. A company with alertMinutes=60 and no CEO would wait 60 minutes instead of 20.

### c14-F007
file: apps/server/src/services/alert-ladder.ts  line: 100  severity: high
The 'run' query picks the earliest CEO run started at/after the raise, regardless of whether that run could see this card (it does not filter by ticketId or by whether the run is still live). A CEO run for a different ticket, or one that already ended, starts this card's clock even though the CEO never saw it — the card then escalates 5 minutes after an unrelated run, defeating the purpose of the change.

### c14-F008
file: apps/server/src/services/alert-ladder.ts  line: 100  severity: medium
The 'run' query does not require the run to still be live (no endedAt check), so a CEO run that started and finished before the sweep still counts as the clock start. Combined with the earliest-run ordering, a short-lived run right after the raise can start the clock for a card the CEO never processed.

### c14-F009
file: apps/server/src/services/alert-ladder.ts  line: 205  severity: high
The CEO wake is now sent with ticketId: null. The dedup that makes 'several cards wake the CEO once' work depends on deps.notify deduping by (agentId, ticketId, reason). With ticketId null, every card shares the same wake key — but the CEO's run then has no ticket context, and any code path that keys wakes by ticketId (e.g. cancellation, per-ticket wake tracking) will not associate this wake with the card. The test only checks the count, not that the CEO can actually see the card.

### c14-F010
file: apps/server/src/services/alert-ladder.ts  line: 273  severity: medium
dueAt issues two extra DB queries per open decision on every sweep. With many open cards this is O(n) queries per sweep tick and can be a hot path; the CEO lookup and run lookup are identical for every card in the same company and should be hoisted out of the loop.

### c14-F011
file: apps/server/src/services/alert-ladder.ts  line: 88  severity: medium
The 'live' query matches any ticketless CEO run that started before the raise and has not ended, even one that started hours earlier and is unrelated to this card. That is arguably intended, but combined with the missing ticketId filter it means a long-running unrelated ticketless CEO run pins every new card's clock to the raise, so cards escalate 5 minutes after being raised even though the CEO is busy on something else.

### c14-F012
file: apps/server/test/team-routing.test.ts  line: 143  severity: low
The 'several cards wake the CEO once' test asserts a single wake but does not verify the wake is actually usable (e.g. that the CEO's run can see both cards). It would pass even if the second card were silently dropped from the CEO's view.

### c14-F013
file: apps/server/test/alert-ladder.test.ts  line: 137  severity: low
The new test 'a card no CEO run ever picks up still reaches the owner at the company's alert time' advances 31+29+2 = 62 minutes and expects the move at 62, but the outer cap is 20 minutes from the raise. With no CEO run, dueAt returns raised + minutes (5 min default), so the card should move at 5 minutes, not 62. The test's expectations (moved=0 at 60, moved=1 at 62) contradict the implementation and only pass because the default alertMinutes is apparently 60 in this fixture — the test name and the 20-minute cap are inconsistent.

### c14-F014
file: apps/server/src/services/alert-ladder.ts  line: 100  severity: high
The 'first CEO run started after the raise' query matches any CEO run started after the raise, including runs that started long after the card was raised and runs that have already ended. A card can therefore be pinned to a run that never saw it, and the 5-minute clock starts from that unrelated run's start time instead of from when the CEO actually began work on the card. It should require the run to be live (endedAt null) or to have started within a window that overlaps the card's life, and ideally to be the run that actually picked up the card.

### c14-F015
file: apps/server/src/services/alert-ladder.ts  line: 96  severity: high
The outer cap is computed as `raised + Math.max(minutes, CEO_OUTER_CAP_MINUTES) * 60_000`. If `alertMinutes` is configured above 20 (the setting is user-configurable per the 'time limit is a setting' test), the cap becomes that larger value, so the card can wait longer than 20 minutes from the raise. The stated intent is a hard 20-minute cap from the raise; it should be `Math.min(minutes, CEO_OUTER_CAP_MINUTES)` or a fixed `CEO_OUTER_CAP_MINUTES`.

### c14-F016
file: apps/server/src/services/alert-ladder.ts  line: 103  severity: medium
When no CEO agent exists, `dueAt` returns `raised + minutes * 60_000` and ignores the outer cap entirely, contradicting the documented 'cap at 20 min from raise' behavior. A company without a CEO (or with a retired CEO) can leave a card waiting past the cap.

### c14-F017
file: apps/server/src/services/alert-ladder.ts  line: 200  severity: high
Changing the CEO-rung notify to `ticketId: null` detaches the wake from the ticket. Downstream consumers that key off `wake.ticketId` (run steering, dedup, activity attribution, the 'steered in' behavior the comment relies on) will no longer associate the wake with the card. The comment claims a ticketless wake lets the CEO's live run be steered to the card, but nothing in this diff wires that steering; the wake is just ticketless.

### c14-F018
file: apps/server/src/services/alert-ladder.ts  line: 200  severity: medium
The 'wake the CEO once for all waiting cards' behavior depends on the scheduler coalescing `reason: "decision"` wakes, but nothing in this diff guarantees that. The new test 'several cards waiting on the CEO wake it once' may pass only because the second `ask()` reuses an existing open decision rather than because of real dedup. If the scheduler does not coalesce, each card produces its own wake and the CEO is woken N times.

### c14-F019
file: apps/server/src/services/alert-ladder.ts  line: 88  severity: medium
`dueAt` issues two extra queries per open CEO-rung decision on every sweep, inside the loop over `open`. With many open cards this is an N+1 query pattern on a hot path (the sweep runs on a timer). The CEO lookup and run lookup should be hoisted out of the per-decision loop or cached per company.

### c14-F020
file: apps/server/src/services/alert-ladder.ts  line: 100  severity: medium
The 'live ticketless run' query uses `or(isNull(runs.endedAt), gte(runs.endedAt, raised))` combined with `lt(runs.startedAt, raised)`. A run that started before the raise and is still open matches, which is intended, but a run that started before the raise and ended exactly at the raise also matches (`gte`), and a run that started before the raise and ended after the raise but was a chat run is filtered by purpose — however the purpose filter is `or(isNull(purpose), ne(purpose, 'chat'))`, so a run with `purpose = null` (legacy rows) is treated as non-chat and can start the clock. That may be acceptable, but it is not documented and differs from the first query's identical filter, so the two queries can disagree about which runs count.

### c14-F021
file: apps/server/test/team-routing.test.ts  line: 110  severity: low
The test inserts a CEO run with `startedAt: ctx.now()` after advancing 10 minutes, then advances 4 and 2. This only exercises the 'run started after the raise' path, not the 'live ticketless run already at the raise' path that the commit message claims to fix. The dedicated test for the live-run case inserts the run before the raise, but the main regression test does not cover the scenario the ticket describes (CEO woken after the 5-minute window has run out).

### c14-F022
file: apps/server/test/temp-cleanup.test.ts  line: 124  severity: low
`ctx.advance(0)` is used to obtain the current time for the inserted run's `startedAt`. If `advance(0)` has side effects (e.g. flushing timers or bumping a counter) this is fragile; more importantly, the inserted run has no `endedAt`, so it is treated as live forever, which masks the case where the CEO run ends before the card is raised.
