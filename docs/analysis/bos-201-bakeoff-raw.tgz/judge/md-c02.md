# Change c02 (merge commit 08512fe) — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c02.diff

ANSWER KEY: file apps/server/src/services/decisions.ts, line ~1356 (line in the new file), type: missing permission / authorisation check
Bug: Removed the guard that stops the CEO (settledBy) from answering 'Let the CEO decide' itself; the hand-off is meant to be owner-only.

## Findings (anonymous ids)

### c02-F001
file: apps/server/src/services/decisions.ts  line: 633  severity: medium
The CEO wake note wraps d.question with untrusted(), but interpolates blocker.title directly. Ticket titles can contain agent-controlled prompt instructions, so this can inject instructions into the CEO's wake note. The title should also be wrapped with untrusted().

### c02-F002
file: apps/web/src/pages/Decisions.tsx  line: 204  severity: medium
Every successful answer marks the decision locally as answered, including "Let the CEO decide". The server deliberately leaves that decision open and returns it to the owner after the CEO timeout. If the page remains mounted, answered[d.id] remains true, so the returned card is displayed as already answered and the owner cannot answer it again. Do not mark handoffs as settled, or clear that state when the card returns.

### c02-F003
file: apps/server/src/services/decisions.ts  line: 630  severity: high
handToCeo updates tier/forAgentId/context but never sets answeredAt or records the owner's answer, and returns a synthetic result. The normal answer path (status transition, activity record, ladder timeout scheduling) is skipped, so the card can sit on the CEO rung forever without the documented 'climbs back to the owner' behavior. The test only checks status stays 'open' and tier 'ceo', which masks the missing timeout.

### c02-F004
file: apps/server/src/services/decisions.ts  line: 628  severity: high
handToCeo builds the wake note with `${untrusted("Boss Man decision", d.question)}` but interpolates `blocker.title` (agent-controlled ticket title) directly into the same note. The commit message claims the wake note is wrapped as untrusted; the blocker title is not, so an agent can inject instructions into the CEO's wake note.

### c02-F005
file: apps/server/src/services/sweeps.ts  line: 100  severity: high
LET_CEO_DECIDE is added to the engagement stale-blocker options too, but handToCeo/hand-off only makes sense for a ticket. The CEO's answer path (validate + apply) only handles `ctx.blockerTicketId` for Reassign; for an engagement blocker the CEO has no way to act on the handed-off card, and the ladder ticketId falls back to blockedTicketId, mislabeling the activity record.

### c02-F006
file: apps/server/src/services/decisions.ts  line: 1355  severity: medium
The hand-off bypasses the `settledBy`/owner-only check that the test asserts. The test 'a CEO agent can't hand the card back to itself' expects an 'Only the owner' error, but the code shown has no such guard in the answer path — the handOff branch runs before any owner check. Either the guard is missing from the diff or the test is asserting behavior the code doesn't implement.

### c02-F007
file: apps/server/src/services/decisions.ts  line: 573  severity: medium
The CEO answering a handed-off card can reassign the blocker to itself (the test does exactly this: `assigneeAgentId: ctx.ceo.id`). That defeats the purpose of handing it off — the CEO becomes the assignee and the card can go stale again with the CEO as owner. There's no check preventing the CEO from picking itself.

### c02-F008
file: apps/web/src/pages/Decisions.tsx  line: 566  severity: medium
The picker's 'Let the CEO decide' button is always rendered, but the server rejects it with 'This company has no CEO to hand it to.' The picker should hide or disable that button when the company has no CEO agent, otherwise the owner hits a dead-end error after opening the picker.

### c02-F009
file: apps/web/src/pages/Decisions.tsx  line: 183  severity: low
openReassign fetches `/api/tickets/${id}` to learn the current assignee, but the picker's 'has it now' marker is cosmetic. If the fetch fails the picker still opens with `current: null`, which is fine, but the fetch is fired on every Reassign click with no caching and no abort — a slow/failed request leaves the picker open with no indication. Minor, but the comment 'The picker still works' hides a silent failure.

### c02-F010
file: apps/server/src/mcp.ts  line: 890  severity: low
The list output filters out 'Let the CEO decide' from the options shown to the CEO, but the CEO's answer path still accepts it (handOff check is on the decision's context, not on who is answering). A CEO could answer 'Let the CEO decide' on a card already on its rung, re-running handToCeo and resetting the ladder `since` — the test asserts this is refused, but the code path shown doesn't refuse it.

### c02-F011
file: apps/server/src/services/decisions.ts  line: 1357  severity: high
handToCeo is invoked for any caller that reaches answer() with answer === LET_CEO_DECIDE; there is no check that the caller is the owner (extra.settledBy absent). The commit message claims 'only the owner can hand a stale blocker to the CEO', but the guard is not in the diff. A CEO agent (or any agent that can answer the card) can re-hand it to itself, keeping it off the owner's queue indefinitely. The added test only exercises the CEO path via decisionsService.answer directly and expects a throw — but that throw comes from the CEO's own-request check, not from an owner-only guard, so it does not prove the guard exists for other agents.

### c02-F012
file: apps/server/src/services/decisions.ts  line: 626  severity: high
handToCeo writes a ladder object into context but never calls the alert-ladder service (no `ladder` argument, no schedule). The doc comment and the UI copy ('it comes back to you if they do not settle it in time') promise the card climbs back to the owner on timeout, but nothing schedules that. The card will sit on the CEO's rung forever if the CEO never answers.

### c02-F013
file: apps/server/src/services/decisions.ts  line: 574  severity: high
When the CEO answers Reassign, the assignee is validated only against the blocking ticket's company — not against the CEO itself. The test 'a CEO agent can't hand the card back to itself' only covers re-handing the card via LET_CEO_DECIDE; it does not cover the CEO reassigning the ticket to itself, which the new test 'Let the CEO decide ... who can then reassign it' actually does (assigneeAgentId: ctx.ceo.id) and expects to succeed. That lets the CEO park the blocking ticket on itself, defeating the point of the hand-off.

### c02-F014
file: apps/server/src/services/decisions.ts  line: 636  severity: medium
The wake note interpolates the blocker ticket title (`the blocking ticket is "${blocker.title}"`) without wrapping it in untrusted(). The commit message says the card text is wrapped as untrusted, but only d.question is wrapped; the blocker title is agent-authored and reaches the CEO's prompt raw.

### c02-F015
file: apps/server/src/mcp.ts  line: 941  severity: medium
assigneeAgentId is forwarded to decisions.answer for every decision kind, not just stale_blocker. Combined with the missing owner-only guard on LET_CEO_DECIDE, a CEO agent can call the decisions tool with answer='Let the CEO decide' on any stale_blocker card it can see and re-hand it to itself. The MCP description also tells the CEO it can answer 'Reassign with assigneeAgentId' but doesn't say the CEO can't pick itself.

### c02-F016
file: apps/web/src/pages/Decisions.tsx  line: 570  severity: medium
The 'Let the CEO decide' button inside the picker calls answer(d, 'Let the CEO decide') directly, bypassing the picker's own validation. That's fine for the CEO hand-off, but it means the picker's 'Reassign to the one I picked' path and the 'Let the CEO decide' path are inconsistent: the latter is also reachable from the plain options list (since LET_CEO_DECIDE is in d.options), so the picker's extra button is redundant and the two paths can diverge if the option is ever removed from d.options on older cards. More importantly, the plain-options button for 'Reassign' only opens the picker when `d.context.blockerTicketId` is set; for engagement blockers (which now also offer LET_CEO_DECIDE but not REASSIGN) the code is fine, but for a stale_blocker card whose blockerTicketId is null the Reassign button falls through to answer(d, 'Reassign') and hits the server-side 'Only a ticket can be reassigned' error instead of opening the picker.

### c02-F017
file: apps/server/src/services/decisions.ts  line: 1357  severity: low
The handOff bypass (`!handOff && !options.includes(answer)`) lets LET_CEO_DECIDE through even when the card's stored options don't include it. That's intentional for old cards, but it also means a stale_blocker card whose options were edited (e.g. by a future change) still accepts the hand-off. Minor, but the bypass should be scoped to stale_blocker cards only — which it is — and the comment says so; flagging in case the intent was narrower.

### c02-F018
file: apps/server/src/services/decisions.ts  line: 574  severity: low
The new `record(...)` for the reassign uses `extra.settledBy ? 'the CEO' : 'the owner'` to label the actor, but settledBy is also set for plan approvers and other non-CEO agents. The activity summary will say 'the CEO' for any agent-settled reassign.
