# Change c10 (merge commit 0221028) — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c10.diff

ANSWER KEY: file apps/server/src/services/review.ts, line ~369 (line in the new file), type: race / ordering
Bug: Removed the claim of the landing before the first await, so two simultaneous approvals can both start a landing.

## Findings (anonymous ids)

### c10-F001
file: apps/server/src/services/review.ts  line: 371  severity: high
startLanding awaits ticketWithRepo before adding the ticket to landings, despite the comment claiming it is claimed before the first await. Two concurrent approvals can both pass the `state === "running"` check, await ticketWithRepo, and then run landOnce for the same ticket. Additionally, if ticketWithRepo rejects, `landings.delete(ticketId)` can delete a claim belonging to another in-flight landing, allowing further duplicate landings.

### c10-F002
file: apps/server/src/services/review.ts  line: 388  severity: high
The running status is set only after awaiting ticketWithRepo(). Two approvals arriving concurrently can both observe no running landing, complete the await, and launch separate merge attempts. Additionally, the earlier catch calls landings.delete(ticketId), which can delete a concurrently started landing's status. Set the running/claimed status before the first await, and only clear a claim owned by that invocation.

### c10-F003
file: apps/server/src/services/review.ts  line: 371  severity: high
The comment claims the landing is 'claimed before the first await', but landings.set(ticketId, running) still happens after `await ticketWithRepo(ticketId)`. Two concurrent approvals both pass the `landings.get(...)?.state === 'running'` guard, both await, and both start a landing — the race the change claims to fix is not fixed.

### c10-F004
file: apps/server/src/services/review.ts  line: 377  severity: high
`landings.delete(ticketId)` in the catch unconditionally removes the entry. If a concurrent startLanding has already replaced it (or will), this deletes the other caller's claim, so a third caller can start yet another landing. Only delete if the entry is still the one this call owns.

### c10-F005
file: apps/server/src/services/review.ts  line: 383  severity: high
When ticketWithRepo throws, the catch records merge_failed and raises the card, then re-throws — but never sets the landing status to 'finished'. In the background path the throw is swallowed by the void async wrapper, so GET /api/tickets/:id/landing reports null/stale forever and the page polls indefinitely. Set a finished status with an outcome before re-throwing.

### c10-F006
file: apps/server/src/services/review.ts  line: 380  severity: medium
The recovery path (db.select, record, raiseMergeStuck) runs inside the catch without its own try/catch. If the original failure was a DB error, these awaits throw too and the original error is replaced by the recovery error; the caller never sees the real cause.

### c10-F007
file: apps/server/src/mcp.ts  line: 908  severity: medium
reviewOutcome's new `outcome === 'landing'` branch is only reachable if settle/overrule actually return `outcome: 'landing'` when `background: true`. The diff doesn't show that change; if settle still returns 'merged'/'done'/'owner_review' synchronously, the new message is dead code and reviewers still get the old text. Confirm settle/overrule emit 'landing'.

### c10-F008
file: apps/server/src/mcp.ts  line: 902  severity: medium
overrule is now called with `background: true`, but the overrule path returns reviewOutcome(r) synchronously. If settle with background:true doesn't return outcome 'landing' for the overrule path, the CEO sees 'Approved; the ticket is done.' while the merge is still running — the exact misleading message this ticket is about.

### c10-F009
file: apps/server/test/review-kinds.test.ts  line: 121  severity: low
Assertion weakened from `toBe('Approved; the ticket is done.')` to `toContain('Approved')`, which matches both the old and new messages. It would pass even if the background-landing message regressed, hiding the behavior this ticket is about.

### c10-F010
file: apps/server/test/review-policy.test.ts  line: 175  severity: low
vi.waitFor without an explicit timeout: if the background landing never finishes (e.g. the missing finished-status bug above), the test hangs until vitest's default timeout instead of failing with a useful message. Add a bounded timeout.

### c10-F011
file: apps/server/src/services/review.ts  line: 368  severity: high
The 'claimed before the first await' comment is false: the running-state guard is checked and the landings entry is only set after `await ticketWithRepo(ticketId)`. Two concurrent approvals both pass the guard and both start a landing; the catch's `landings.delete(ticketId)` can also delete the entry the other concurrent call just set, defeating the 'already being checked' guard.

### c10-F012
file: apps/server/src/services/review.ts  line: 375  severity: high
The catch block calls db.select/record/raiseMergeStuck without its own try/catch. If any of those throws (the same DB problem that made ticketWithRepo fail is likely), the original error is masked and the landing entry has already been deleted, so the approved ticket is left with no record and no card — the exact silent-stuck case this change is meant to prevent.

### c10-F013
file: apps/server/src/services/review.ts  line: 419  severity: medium
land() now converts any non-ReviewError (DB/git crash) into a merge_failed record and an owner merge-stuck card, then rethrows. For a transient error this permanently marks the ticket merge_failed and raises a card even though a retry could succeed; and the isLeader handover branch still rethrows without recording, so a non-leader copy that crashes mid-merge leaves nothing behind.

### c10-F014
file: apps/server/src/mcp.ts  line: 962  severity: medium
The new `outcome === "landing"` branch in reviewOutcome is only reachable if settle() returns { outcome: "landing" }. The submit path returns before land() runs, so unless settle is updated to return that outcome for background approvals, reviewers still see 'Approved; the ticket is done.' while the merge is still pending — the new message never fires.

### c10-F015
file: apps/server/test/review-kinds.test.ts  line: 121  severity: medium
Assertion weakened from `.toBe("Approved; the ticket is done.")` to `.toContain("Approved")`, which also passes for the 'couldn't merge yet' and 'being checked' messages. The test no longer distinguishes a successful merge from a failed one; it should assert the new background message specifically.

### c10-F016
file: apps/server/test/review-kinds.test.ts  line: 174  severity: medium
Same weakening for the CEO overrule case: `.toContain("Approved")` matches the failure message too, so a regression where the overrule fails to merge would still pass.

### c10-F017
file: apps/server/test/review-policy.test.ts  line: 301  severity: low
The two `submit(...)` assertions were loosened to `.toContain("being checked and merged in the background")`; combined with the vi.waitFor on systemState this is OK, but the earlier `expect(await submit(t.id)).toBe(...)` for the owner-signoff case still uses toContain and would not catch a regression where the background message is shown for an owner-signoff ticket that should not be landing.
