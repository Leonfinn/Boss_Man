# Change c08 (merge commit d23ef92) — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c08.diff

ANSWER KEY: file apps/runner/src/workspace.ts, line ~467 (line in the new file), type: resource leak
Bug: Removed the SIGKILL of the process group once the check has finished, so stray pnpm/vitest workers survive a normal exit (the very leak the change is meant to fix).

## Findings (anonymous ids)

### c08-F001
file: apps/runner/src/workspace.ts  line: 467  severity: high
The hard-kill timeout calls finish(null) but never sends SIGKILL to the process group. Descendants that ignore SIGTERM remain alive after verify() resolves, so the reported timeout does not actually stop pnpm/vitest and can leak processes until they exit on their own.

### c08-F002
file: apps/runner/src/workspace.ts  line: 472  severity: high
After the timeout, the code sends SIGTERM to the process group but the grace-period timer only calls finish(null); it never sends SIGKILL. Any descendant that ignores or delays SIGTERM (including pnpm/vitest workers) keeps running after verify() has resolved, so repeated checks can still exhaust the process limit.

### c08-F003
file: apps/runner/src/workspace.ts  line: 476  severity: high
The hard-kill grace timer only calls finish(null); it never sends SIGKILL to the process group. Grandchildren that ignore SIGTERM (the exact scenario the new test claims to cover) survive the timeout, so the process-limit leak the ticket describes is not fixed. It should call killGroup("SIGKILL") before finishing.

### c08-F004
file: apps/runner/src/workspace.ts  line: 470  severity: high
Resolution depends on child 'close', which only fires once stdout/stderr pipes are closed. If the shell exits but a grandchild inherits the pipes and keeps them open (common with pnpm/vitest workers), 'close' never fires and the promise hangs until the hardKill timer, which (per above) doesn't actually kill anything. The result is a hung verify() and leaked processes.

### c08-F005
file: apps/runner/test/merge.test.ts  line: 138  severity: high
The test does not actually verify the grandchild was killed. `(trap '' TERM; sleep 60) & ... wait` — SIGTERM to the group kills the shell (which has no trap), so `wait` returns and the test's polling loop sees the shell's pid gone, not the grandchild's. The grandchild (which ignores TERM) is still alive. The test passes even with the buggy implementation, giving false confidence.

### c08-F006
file: apps/runner/src/workspace.ts  line: 462  severity: medium
child.stdout and child.stderr are typed as possibly null (Readable | null) with stdio: ["ignore","pipe","pipe"]. Calling setEncoding/on without a null check will fail typecheck under strict null checks, or throw at runtime if the pipe is unavailable.

### c08-F007
file: apps/runner/src/workspace.ts  line: 484  severity: low
The 'error' handler appends err.message to tail and calls finish(null), but if 'close' already fired (or fires later) the message may be lost or duplicated. Also, on spawn error the process group may not exist; killGroup is not attempted, which is fine, but the error path doesn't clear the timer before finish — finish does clear it, so this is only a minor ordering concern.

### c08-F008
file: apps/runner/src/workspace.ts  line: 470  severity: high
On timeout the code sends SIGTERM to the group, then after VERIFY_KILL_GRACE_MS just calls finish(null) without sending SIGKILL to the group. Processes that ignore SIGTERM (or are still shutting down) survive, so the original leak (pnpm/vitest eating the process limit) is not fixed. The hard-kill timer must call killGroup("SIGKILL") before finishing.

### c08-F009
file: apps/runner/test/merge.test.ts  line: 138  severity: medium
The test does not actually verify SIGKILL escalation: `(trap '' TERM; sleep 60) &` traps TERM in the subshell, but the `sleep` child still receives SIGTERM and dies. So the test passes even though the implementation never sends SIGKILL. It should spawn a process that ignores SIGTERM itself (e.g. `sh -c 'trap "" TERM; sleep 60' &`) to exercise the hard-kill path.

### c08-F010
file: apps/runner/src/workspace.ts  line: 466  severity: medium
After finish() resolves on the hard-kill timer, the child's stdout/stderr pipes are still open (the group wasn't killed), so the 'close' event may never fire and the child handle is never released; the process group remains orphaned. Combined with the missing SIGKILL this leaves the group running indefinitely.
