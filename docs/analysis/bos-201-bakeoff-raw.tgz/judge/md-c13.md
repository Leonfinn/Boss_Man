# Change c13 (merge commit 0faf7da) — CLEAN CONTROL (nothing seeded)
Diff the models saw: /tmp/bakeoff/diffs/c13.diff

## Findings (anonymous ids)

### c13-F001
file: apps/server/src/services/watchdog.ts  line: 902  severity: medium
The new ticket join and the subsequent agent/decision lookups filter only by globally referenced IDs, not by companyId. Although the actions themselves are company-scoped, a cross-company or inconsistent ticketId/targetAgentId/decisionId causes the response to disclose another tenant's ticket number, agent name/role, or decision question. Scope every join and lookup to the requested company (and enforce the same tenant relationship in inserts/schema constraints).

### c13-F002
file: apps/server/src/services/watchdog.ts  line: 903  severity: medium
The new agent, ticket, and decision lookups are joined by ID without also constraining them to companyId. Although the IDs are usually UUIDs, IDs are not tenant boundaries: a malformed or cross-company reference in watchdogActions could expose another company's agent name, ticket number, or decision question through this company-scoped API. Add company predicates to these joins/lookups.

### c13-F003
file: apps/web/src/components/ScrumMasterLog.tsx  line: 33  severity: medium
When targetAgentId exists but the target cannot be resolved, targetName is null and the heading falls back to "you". A deleted or otherwise missing target is therefore falsely reported as the warning having been passed to the owner rather than identifying the recipient as unknown.

### c13-F004
file: apps/server/src/services/watchdog.ts  line: 906  severity: medium
The actions() query now issues three extra DB round-trips (companies, agents, decisions) on every call. The web log polls this endpoint every 15s per mounted ScrumMasterLog, so this multiplies load; the companies lookup in particular is unconditional even when no rows need a ticketRef.

### c13-F005
file: apps/server/src/services/watchdog.ts  line: 911  severity: medium
ticketRef(c?.prefix, r.ticketNumber) is called with r.ticketNumber possibly null (left join to tickets can miss) and c possibly undefined; behavior depends on ticketRef's signature which isn't shown, but passing null/undefined here is a likely source of 'null-123' or thrown errors in the log line.

### c13-F006
file: apps/web/src/components/ScrumMasterLog.tsx  line: 30  severity: low
actionHeading falls back to 'Something happened' for unknown kinds, but the test only asserts the result has no underscore — it doesn't assert the fallback text, so a regression that shows a raw kind without an underscore (e.g. 'brandnewthing') would pass. The test gives false confidence.

### c13-F007
file: apps/web/test/action-labels.test.ts  line: 12  severity: medium
The test asserts Object.keys(WATCHDOG_ACTION_LABEL) exactly equals WATCHDOG_ACTIONS, but the diff adds alert_hop and alert_resolved to the label map without showing them added to WATCHDOG_ACTIONS. If they aren't already in that array, this test fails; if they are, the type Record<WatchdogActionKind,string> already enforces completeness and the equality check is redundant but harmless. Either way the diff doesn't demonstrate the two new kinds are in WATCHDOG_ACTIONS.

### c13-F008
file: apps/web/src/components/ScrumMasterLog.tsx  line: 63  severity: low
The ticketRef link is only rendered for alert_hop/alert_resolved rows, so other rows that now carry a ticketRef (the query returns it for every action) silently drop it. Inconsistent with the stated goal of showing the ticket on every logged action.

### c13-F009
file: apps/web/test/action-labels.test.ts  line: 12  severity: high
Test asserts Object.keys(WATCHDOG_ACTION_LABEL) equals WATCHDOG_ACTIONS, but the diff adds alert_hop/alert_resolved labels without showing them added to WATCHDOG_ACTIONS. Either the test fails, or the diff is incomplete and the new kinds aren't in the union type — in which case the label map's Record<WatchdogActionKind, string> won't type-check with the extra keys.

### c13-F010
file: apps/server/src/services/watchdog.ts  line: 906  severity: medium
inArray(agents.id, targetIds) and inArray(decisions.id, decisionIds) are unbounded — up to 500 rows each, so up to 500 ids per IN clause. On SQLite/Postgres this can hit parameter limits or be slow; should chunk or cap.

### c13-F011
file: apps/server/src/services/watchdog.ts  line: 908  severity: medium
warning is derived from after.decisionId, but alert_hop rows likely record the hop target/decision in a different field (or the decisionId may be on the original alert, not the hop). If alert_hop rows don't carry after.decisionId, the 'which warning it was' text will always be null and the feature silently doesn't work.

### c13-F012
file: apps/server/src/services/watchdog.ts  line: 903  severity: medium
targetIsScrumMaster/targetIsCeo are computed from the agent's current role/duty, not the role at the time of the hop. If an agent's role changes later, historical log lines will mislabel who the warning went to (e.g. show 'the CEO' for a hop that went to a non-CEO).

### c13-F013
file: apps/web/src/components/ScrumMasterLog.tsx  line: 68  severity: low
ticketRef is fetched for every row but only rendered for alert_hop/alert_resolved. Other rows lose the ticket reference the server now provides; either render it for all rows or don't fetch it for non-alert rows.

### c13-F014
file: apps/web/src/components/ScrumMasterLog.tsx  line: 33  severity: low
actionHeading falls back to 'Something happened' for unknown kinds, but the test only checks it doesn't contain '_'. A raw kind like 'brand_new_thing' would still be hidden, but the fallback loses the kind entirely for debugging; consider including the kind in a data attribute or title.
