import fs from "node:fs";
const O = "/tmp/bakeoff", KEY = process.env.OLLAMA_API_KEY;
const MODELS = { minimax: "minimax-m3.1-flash", deepseek: "deepseek-v4.1-flash:1017", glm: "glm-5.3-flash" };
const only = process.argv[2];
const meta = JSON.parse(fs.readFileSync(`${O}/meta.json`, "utf8"));
const SYSTEM = "You are a careful senior engineer doing a code review of a pull request for a TypeScript monorepo (Fastify + Drizzle server, React web app, a Node runner, and shell scripts). Report only problems you believe are real. Do not pad the review with style nits or praise.";
const prompt = (m, diff) => `Ticket: ${m.title}\n\nDescription (the commit messages on the branch):\n${m.commits}\n\nReview this change (a unified diff against the branch base). Find bugs, missing checks, security problems and logic errors introduced or left in by the change.\n\nReply with a short summary, then a JSON array in a \`\`\`json fenced block. Each element: {"file": string, "line": number (line in the new file), "severity": "high"|"medium"|"low", "reason": string}. Use [] if you find nothing.\n\n\`\`\`diff\n${diff}\n\`\`\``;
async function one(name, m, run) {
  const out = `${O}/${process.env.OUTDIR||"out"}/${name}/${m.id}-r${run}.json`;
  if (fs.existsSync(out)) { const j = JSON.parse(fs.readFileSync(out, "utf8")); if (j.ok) return; }
  const diff = fs.readFileSync(`${O}/diffs/${m.id}.diff`, "utf8");
  const body = { model: MODELS[name], stream: true, ...(process.env.THINK==="1"?{}:{think:false}), options: { temperature: 0.2, num_predict: Number(process.env.NUM_PREDICT||16000) }, messages: [{ role: "system", content: SYSTEM }, { role: "user", content: prompt(m, diff) }] };
  const rec = { change: m.id, model: MODELS[name], run, ok: false };
  for (let attempt = 1; attempt <= 3; attempt++) {
    const t0 = Date.now(); rec.attempts = attempt;
    try {
      const r = await fetch("https://ollama.com/api/chat", { method: "POST", headers: { Authorization: `Bearer ${KEY}`, "Content-Type": "application/json" }, signal: AbortSignal.timeout(900_000), body: JSON.stringify(body) });
      rec.wallMs = Date.now() - t0; rec.status = r.status;
      if (!r.ok) { const text = await r.text(); rec.error = text.slice(0, 300); if (r.status === 429 || r.status >= 500) { await new Promise(s => setTimeout(s, 20000 * attempt)); continue; } break; }
      let content = "", thinking = "", last = {}, buf = "";
      const dec = new TextDecoder();
      for await (const chunk of r.body) { buf += dec.decode(chunk, { stream: true }); let i; while ((i = buf.indexOf("\n")) >= 0) { const l = buf.slice(0, i); buf = buf.slice(i + 1); if (!l.trim()) continue; let j; try { j = JSON.parse(l); } catch { continue; } if (j.error) rec.error = j.error; content += j.message?.content ?? ""; thinking += j.message?.thinking ?? ""; if (j.done) last = j; } }
      if (rec.error && !content) { await new Promise(s => setTimeout(s, 10000 * attempt)); continue; }
      const j = last;
      rec.content = content; rec.thinkingChars = thinking.length;
      rec.promptTokens = j.prompt_eval_count; rec.outputTokens = j.eval_count; rec.apiMs = j.total_duration ? Math.round(j.total_duration / 1e6) : null; rec.doneReason = j.done_reason;
      rec.ok = !!rec.content; delete rec.error; if (!rec.ok) rec.error = "empty content"; else break;
    } catch (e) { rec.wallMs = Date.now() - t0; rec.error = String(e); }
  }
  fs.mkdirSync(`${O}/${process.env.OUTDIR||"out"}/${name}`, { recursive: true });
  fs.writeFileSync(out, JSON.stringify(rec, null, 1));
  console.log(name, m.id, "r" + run, rec.ok ? "ok" : "FAIL " + rec.error, rec.wallMs + "ms", rec.outputTokens);
}
for (const name of only ? [only] : Object.keys(MODELS)) {}
const names = only ? [only] : Object.keys(MODELS);
await Promise.all(names.map(async (n) => { for (const run of [1, 2]) for (const m of meta) await one(n, m, run); }));
console.log("DONE");
