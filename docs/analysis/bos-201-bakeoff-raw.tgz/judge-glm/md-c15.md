# Change c15 — CLEAN CONTROL (no seeded bug)
Diff the models saw: /tmp/bakeoff/diffs/c15.diff

## Findings (anonymous ids)

### c15-G001
file: apps/web/src/pages/Board.tsx  line: 420  severity: low
featureFilter is guarded against featureList, which is empty until the features poll first resolves (and stays empty if that request fails). A saved feature filter is therefore silently treated as "any" during load: the board briefly renders tickets the saved filter should exclude, and the select displays "Any feature" while filters.feature still holds the saved id, then snaps to the filtered view when the list arrives. Because the fallback is never written back to state/sessionStorage, the stale id also persists and will silently re-activate the filter if a feature with that id appears later. Computing the guard only once the feature list is loaded (or reconciling the stored value) would avoid the mismatch.

### c15-G002
file: apps/web/src/pages/Board.tsx  line: 420  severity: low
featureFilter validates the saved id against featureList, which is empty until the /features poll resolves. On every mount a saved feature filter is therefore downgraded to "any": the select flashes "Any feature" and cards render unfiltered, then abruptly re-filter when the list arrives (and the saved filter never applies at all if the features request fails for the session). The stored value also keeps the dead id after the fallback, so the select and sessionStorage disagree until the user re-picks. Validate only once the list has loaded, or persist the resolved choice, to avoid the flash and the silent drop.

