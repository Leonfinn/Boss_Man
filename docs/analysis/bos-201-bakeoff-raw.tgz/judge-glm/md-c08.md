# Change c08 — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c08.diff

ANSWER KEY: file apps/runner/src/workspace.ts, line ~467, type: resource leak
Bug: Removed the SIGKILL of the process group once the check has finished, so stray pnpm/vitest workers survive a normal exit (the very leak the change is meant to fix).

## Findings (anonymous ids)

### c08-G001
file: apps/runner/src/workspace.ts  line: 472  severity: high
The grace timer never escalates to SIGKILL; it only calls finish(null) to resolve the promise. A merge check whose processes ignore or trap SIGTERM is never killed, so the original bug (leftover pnpm/vitest workers consuming the process limit) persists. The new test proves it: the TERM-immune subshell survives the SIGTERM and keeps the stdio pipes open, so 'close' never fires, verify only returns via this fallback at timeout+2s, and the subshell is still alive when the test polls. The callback should call killGroup("SIGKILL") and let the subsequent 'close' event produce the result (keeping finish(null) only as a last-resort fallback).

### c08-G002
file: apps/runner/test/merge.test.ts  line: 142  severity: low
Liveness probe counts zombies as alive: process.kill(pid, 0) succeeds for a zombie. Once the group is SIGKILLed, the subshell has already been reparented (its parent shell died at the SIGTERM) to pid 1 or the nearest subreaper; in a container where pid 1 does not reap orphans (e.g. Node as pid 1, since libuv only reaps PIDs it spawned itself), the killed process remains a zombie and the poll loop never observes it dead, making the test flaky even once the missing SIGKILL is fixed. Checking /proc/<pid>/stat state (or the process's exit status) would be robust.

### c08-G003
file: apps/runner/src/workspace.ts  line: 472  severity: high
The grace timer never escalates to SIGKILL: `hardKill = setTimeout(() => finish(null), VERIFY_KILL_GRACE_MS)` only resolves the promise. A group member that ignores SIGTERM (the new test's `trap '' TERM; sleep 60`, or vitest workers with stubborn TERM handlers) is never killed — the runner just stops waiting while pnpm/vitest keep running, which is precisely the leak this ticket is about. The pipes and ChildProcess handles also stay open until the survivors exit on their own. The newly added test asserts the grandchild is dead within ~2s and will fail against this code. hardKill should call killGroup("SIGKILL") and let 'close' (or a final fallback) produce the result.

### c08-G004
file: apps/runner/src/workspace.ts  line: 478  severity: low
Completion is gated on 'close', which only fires once every holder of the inherited stdout/stderr pipes has closed them. If the check's shell exits on time but a grandchild keeps the pipes open, verify blocks until the timeout fires, SIGTERMs the group, and then reports the check as { timedOut: true, exitCode: null } even though the check itself succeeded — the real exit code is discarded. Resolving on 'exit' (and reaping leftover group members) would keep the result faithful to the check's own outcome.

### c08-G005
file: apps/runner/src/workspace.ts  line: 467  severity: low
The process group is only killed on the timeout path. On a normal finish, any background process the check spawned (e.g. a daemon that redirected its output) stays alive in the group indefinitely, still consuming the process limit the ticket complains about. Since the group exists for exactly this purpose, finish() could SIGKILL any remaining members after resolving.

