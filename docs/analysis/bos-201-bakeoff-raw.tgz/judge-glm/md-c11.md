# Change c11 — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c11.diff

ANSWER KEY: file apps/server/src/services/review-policy.ts, line ~83, type: missing permission / authorisation check
Bug: The hand-over pool no longer excludes the ticket's author, so a review can be moved to the agent who wrote the change.

## Findings (anonymous ids)

### c11-G001
file: apps/server/src/services/review-policy.ts  line: 83  severity: high
otherReviewers never uses its author parameter: the filter only drops paused and explicitly excluded agents, and handOverReviews passes only [wake.agentId] as exclude. So a review stuck behind a busy reviewer can be handed to the ticket's assignee (the author of the work), who is typically free at that point, and can then approve their own ticket. This breaks the invariant resolveKindReviewer enforces (`a.id !== author`) and contradicts the function's own doc comment ('never the author').

### c11-G002
file: apps/server/src/services/review-kinds.ts  line: 109  severity: medium
reviewWaits is a sequential N+1: latestRows per ticket, then per pending review row an agents lookup, a live-runs join scan, and often a wakes lookup, all awaited in a loop. It is called from the board list endpoint (work.ts) with every in-review ticket id on each poll and from listReviews on every ticket-page poll, adding dozens to hundreds of queries per request on hot paths.

### c11-G003
file: apps/server/src/services/review-kinds.ts  line: 166  severity: low
Returning null conflates 'every block was handed over' with 'the note had no parseable blocks': a review wake with an empty/whitespace note that has waited past the threshold is dropped by the scheduler as 'handed to another reviewer' even though nothing was handed over, leaving its pending reviewRequests row with no wake to ever launch it.

### c11-G004
file: apps/server/src/services/review-kinds.ts  line: 101  severity: low
waitingOn is a ticket-level string attached to every pending row: when a ticket has several pending reviews by different reviewers, each row (including pending rows of older rounds) renders lines about the other rows' reviewers, e.g. the code-review row shows 'Sam is about to start', which is about the security review.

### c11-G005
file: apps/server/src/services/review-kinds.ts  line: 160  severity: low
waitedMs is the wake's age (time since the first review note), not how long the reviewer has been busy. The activity summary 'was busy for N minutes' can materially overstate, and handover can fire immediately after the reviewer actually becomes busy if the wake first sat 10 minutes behind instance/company limits or batching deferrals.

### c11-G006
file: apps/server/src/services/review-policy.ts  line: 83  severity: high
otherReviewers never excludes the author: the `author` parameter is accepted but unused, and the only caller (handOverReviews) passes just [wake.agentId] in `exclude`. Contrary to the function's own doc comment ("...and never the author"), a review can be handed to the ticket's assignee, who then reviews and can approve their own work. resolveKindReviewer does exclude the author (a.id !== author), so this breaks the established invariant. The new test named "...paused, or the author" never actually makes the candidate the assignee, so the gap is untested.

### c11-G007
file: apps/server/src/services/review-kinds.ts  line: 166  severity: medium
handOverReviews returns null both when every review was successfully handed over and when the note yields no blocks at all (null/empty/unparseable note). The scheduler treats null as success and drops the wake with statusReason "handed to another reviewer" (scheduler.ts ~967), so a REVIEW_REASON wake with an empty or legacy-format note is dropped without any review being moved — the review request stays pending with no wake anywhere, and the ticket is stuck in review with nothing that will ever pick it up.

### c11-G008
file: apps/server/src/services/review-kinds.ts  line: 128  severity: medium
reviewWaits never checks the reviewer's paused/retired state, so a paused reviewer with a queued wake is reported as "about to start". Correspondingly, the scheduler's handover branch sits after the `pausedAgents` early-continue (scheduler.ts ~956-959), so reviews held by a paused (or retired) reviewer are never handed over at all — they stall indefinitely while the board/card claims the reviewer is about to start.

### c11-G009
file: apps/server/src/services/work.ts  line: 187  severity: medium
reviewWaits is an N+1: for each ticket it re-queries latestRows, then per pending review runs 2-3 more sequential queries (agent name, live run, wake). It is now called with every review-state ticket on each board listing, so board latency grows as roughly (tickets-in-review × pending-reviews × 3) sequential queries per request, on every poll.

### c11-G010
file: apps/server/src/services/review-kinds.ts  line: 160  severity: low
The handover activity summary says "<name> was busy for N minutes" using the wake's age (waitedMs = now - wake.createdAt), not how long the reviewer has actually been busy; the wake may have waited most of that time before the reviewer started their current run, so the recorded ticket log can be materially wrong (the test even asserts the misleading wording).

### c11-G011
file: apps/server/src/services/review-kinds.ts  line: 101  severity: low
The ticket-level waiting line is attached to every pending review row, so with multiple reviewers each row shows the aggregate: e.g. the security reviewer's row displays "Ada is busy on BOS-7" even though that row waits on a different reviewer (or on nothing), misattributing the blocker on the ticket page.

