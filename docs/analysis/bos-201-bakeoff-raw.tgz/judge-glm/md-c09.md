# Change c09 — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c09.diff

ANSWER KEY: file apps/server/src/services/sweeps.ts, line ~41, type: wrong operator / boundary
Bug: The sweep's merge-retry delay is the check timeout MINUS 5 minutes instead of plus, so a check that is still running is mistaken for a stopped one and a second landing can start.

## Findings (anonymous ids)

### c09-G001
file: apps/server/src/services/review.ts  line: 449  severity: medium
The heartbeat is now the only thing keeping a live landing out of the sweep, and it fails silently: touch() rejections are discarded via .catch(() => undefined). If ticket writes fail for roughly mergeMissedAfterMs (DB failover, exhausted pool) while a verify/merge ask is still pending, lastActivityAt goes stale, the sweep finds the approval 'passed', and retryLand starts a second landing beside the live one — exactly the bug being fixed — with nothing logged to explain it. The inter-ask phases (e.g. prTarget) are also un-heartbeated. At minimum log/alert on heartbeat failure; better, add a real landing-in-progress marker that landOnce checks instead of only systemState === "done".

### c09-G002
file: apps/server/src/services/sweeps.ts  line: 305  severity: low
The guard is advisory, not exclusive: the sweep decides from the lastActivityAt snapshot read at SELECT time, then runs several awaited queries (latestRows, sign-off lookup) before calling retryLand, while landOnce only bails when systemState === "done". A landing that starts inside that select→retry window (ticket legitimately stale, then approved) still runs concurrently — duplicate verify runs and a second merge/push ask for the same ticket. Re-checking freshness (or an in-progress flag) immediately before retrying would close the window the change claims to close.

### c09-G003
file: apps/server/src/services/sweeps.ts  line: 26  severity: low
The comment states the wrong invariant: mergeMissedAfterMs = VERIFY_ASK_TIMEOUT_MS - 5 * 60_000 is five minutes SHORTER than the server's wait for a verify check, so the threshold alone does not ensure 'a check that is still running is never mistaken for one that stopped' — only the 60s heartbeat does. The value is longer only than MERGE_WAIT_MS. Someone trusting the comment (e.g. concluding the heartbeat is redundant belt-and-braces and removing it) would reintroduce the bug for checks running between mergeMissedAfterMs and VERIFY_ASK_TIMEOUT_MS.

### c09-G004
file: apps/server/src/services/sweeps.ts  line: 305  severity: medium
The double-landing race is narrowed, not closed: freshness is checked only in the SELECT, and nothing re-validates before retryLand. landOnce has no in-flight guard (only the systemState==="done" early-out), so a landing that starts between the sweep's SELECT and its retry — e.g., the approval commits while the sweep is processing the batch, or landOnce's first touch lands after the SELECT read — still runs a second verify/merge beside the live one. Re-check lastActivityAt (or take a claim/in-flight marker) immediately before retrying, or make landOnce refuse concurrent landings.

### c09-G005
file: apps/server/src/services/review.ts  line: 449  severity: low
The heartbeat swallows DB failures (touch().catch(() => undefined)). If the lastActivityAt writes fail persistently during a long verify, the sweep sees stale activity and starts a second landing — exactly the bug this change fixes — with no log or signal that the guard failed open. At minimum log the failure.

### c09-G006
file: apps/server/src/services/sweeps.ts  line: 41  severity: low
mergeMissedAfterMs = VERIFY_ASK_TIMEOUT_MS - 5min is shorter than the verify ask timeout it is derived from, so the doc comment's guarantee ("a check that is still running is never mistaken for one that stopped") does not follow from the threshold; it holds only while the heartbeat wrappers in landOnce are beating, and those wrap only the runner asks — other awaits (e.g., the prTarget git-host check in review.ts) are uncovered. Either size the threshold above VERIFY_ASK_TIMEOUT_MS or correct the comment to name the heartbeat as the actual guard.

