# Change c07 — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c07.diff

ANSWER KEY: file apps/server/src/services/self-deploy.ts, line ~164, type: missing null / empty check
Bug: Removed the guard for no deployed commit: with deployed null every open hand-apply to-do looks 'caught up' (null !== fromCommit) and is cleared.

## Findings (anonymous ids)

### c07-G001
file: apps/server/src/mcp.ts  line: 70  severity: medium
The covering check treats ANY open decision this agent raised as covering the ask, with no tier/queue filter. An agent with an unrelated pending plan or permission approval (both carry raisedByAgentId and stay open until answered) never gets the hint, so its request to the owner still never reaches the owner's queue — the exact gap BOS-122 claims to fix. Same for open decisions blocking the ticket that sit on the CEO's or agent's queue rather than the owner's.

### c07-G002
file: apps/server/src/mcp.ts  line: 57  severity: medium
OWNER_ASK matches the agent narrating its own actions: "I'll run the migration next", "I'll apply it tomorrow", "going to try again", "I'll revert the change" all match (run the / apply it / try again / revert), as can watcher status replies the code itself frames as status updates (R80). The result then assertively says "no open decision covers it — Call raise_decision…", so routine status replies push agents to raise spurious decisions that land as junk cards on the owner's queue.

### c07-G003
file: apps/server/src/services/decisions.ts  line: 186  severity: low
Dedupe-key lifecycle is one-sided: only clearOwnerTodo clears dedupeKey. Answering the to-do "Done, it's applied" goes through the generic answer path, which keeps the key (evidenced by the existing Not-now dedupe test and by the send-failure revert not restoring a key). A later approval for the same commit (e.g. re-raised via "Deploy latest" after a rollback) answered "Approve" then hits onConflictDoNothing, raiseOwnerTodo returns null, and no to-do is left on the queue — the approval clears with nothing behind it.

### c07-G004
file: apps/server/src/services/decisions.ts  line: 1203  severity: low
The raiseOwnerTodo call is unguarded, unlike the adjacent host-send path: the generic flow has already marked the approval answered before this branch runs, so if the insert throws, the approval is consumed with no to-do, no error recovery, and no way to re-trigger the hand-apply (the send path explicitly re-opens the decision on failure; this one doesn't).

### c07-G005
file: apps/server/src/services/self-deploy.ts  line: 167  severity: low
clearDoneOwnerTodos selects open owner_todos with no companyId filter, and clearOwnerTodo matches by dedupeKey alone across all companies, so this host's reported commit clears matching "Waiting for you" cards in every company. Safe today only because self-deploy is home-company-scoped and the key embeds a commit sha, but the context shape already anticipates other to-do sources (deployId), where this would wrongly clear other companies' cards.

### c07-G006
file: apps/server/src/services/decisions.ts  line: 1205  severity: low
The to-do question quotes d.question.split("\n\n")[0], but the infra approval question is a single paragraph with no blank line, so the entire approval text — including the now-stale instruction "Approve this and a to-do stays on your queue… It clears when you mark it done…" — is embedded verbatim inside the to-do card's title.

### c07-G007
file: apps/server/src/services/self-deploy.ts  line: 186  severity: low
sync() now dereferences this.clearDoneOwnerTodos on a factory-returned object literal. Any call site that registers or destructures sync unbound (a common pattern for poller callbacks — the phase-3 leader scheduler is exactly such a caller) throws at runtime; previously sync was this-free. Defining clearDoneOwnerTodos as a local function before the returned object would remove the binding dependency.

### c07-G008
file: apps/server/src/services/self-deploy.ts  line: 171  severity: high
caughtUp = a.deployed !== ctx.fromCommit treats any live-commit change as 'the hand-apply reached the host'. With two approved hand-apply to-dos sharing the same approval-time commit (consecutive infra commits, no intervening deploy: to-do1 commit B / fromCommit A, to-do2 commit D / fromCommit A — P2 is raised while to-do1's to-do is open because pending() only guards self_deploy offers), applying to-do1 moves deployed to B, which auto-clears to-do2 too even though D's changes were never applied; the card closes claiming 'The approved change to B is applied' (naming the wrong commit). Since answered approvals keep their dedupeKey (only clearOwnerTodo nulls it), the offer for D may then never be re-raised. A rollback to anything other than fromCommit, or a revert of the commit on main, false-clears the same way.

### c07-G009
file: apps/server/src/mcp.ts  line: 58  severity: medium
OWNER_ASK matches ordinary status-update phrasing, not just owner-directed asks: 'you should see the new banner', 'please see the logs below', "I'll run the tests next", "I'll try again shortly" all match, and watcher status replies (R80) are not excluded. Agents are told to raise a blocking decision for plain status updates, creating exactly the owner-queue noise BOS-122 is meant to avoid.

### c07-G010
file: apps/server/src/mcp.ts  line: 71  severity: medium
The covering check is wrong in both directions. (a) eq(decisionsTable.raisedByAgentId, scope.agentId) matches ANY open decision the agent raised on any ticket (e.g. an unrelated permission or budget request), suppressing the hint so genuine owner asks on this ticket can still get lost — the failure BOS-122 targets; the comment says 'already asked about it' but nothing ties the decision to this ticket. (b) An open owner_todo card (the very hand-apply the reply asks about) satisfies neither branch, so the agent is told nothing is on the owner's queue and can raise a duplicate decision.

### c07-G011
file: apps/server/src/services/self-deploy.ts  line: 163  severity: medium
clearDoneOwnerTodos(a: Available | null) dereferences a.deployed (lines 171 and 173) without narrowing. Under strictNullChecks — which this codebase clearly uses, given the pervasive non-null assertions — this is a tsc error in new code; vitest/esbuild transpile without typechecking, so tests won't catch it. Also a runtime crash if ever called with null.

### c07-G012
file: apps/server/src/services/decisions.ts  line: 1216  severity: low
For an infra card the guard is only 'ctx.infra && answer === APPROVE_HAND_APPLY'; the else-if still sends on DEPLOY/UPDATE_RUNNERS. Any 'Deploy' answer on an infra decision (crafted or unvalidated API call — the card's options are now Approve/Not now) reaches selfDeploy.send and writes a deploy request for a change Boss Man is explicitly barred from deploying. Should be 'else if (!ctx.infra && ...)'.

### c07-G013
file: apps/server/src/services/decisions.ts  line: 1203  severity: low
The APPROVE_HAND_APPLY path has no failure handling around raiseOwnerTodo, unlike the DEPLOY path which re-opens the decision when the host write fails. If the insert throws after the approval was marked answered, the approval is consumed and no to-do is left — the exact lost-hand-apply state this change exists to prevent (the manual re-open in the DEPLOY path suggests the answer flow is not transactional).

### c07-G014
file: apps/server/src/services/self-deploy.ts  line: 186  severity: low
sync() calls this.clearDoneOwnerTodos(a), so clearing only works while sync is invoked as a method (selfDeploy.sync()). If the leader loop ever aliases or destructures sync, every poll throws at the first successful available(). Reference the function directly instead of via this.

### c07-G015
file: apps/server/src/services/self-deploy.ts  line: 164  severity: low
clearDoneOwnerTodos selects open owner_todo decisions with no companyId filter (and clearOwnerTodo updates by dedupeKey alone), so any company's to-do is cleared against this host's deployed commit. Safe only while owner to-dos are exclusively home-company/self-deploy raised; raiseOwnerTodo is exported and parameterised for agent-raised to-dos, so the invariant is easy to break.

### c07-G016
file: apps/server/src/services/self-deploy.ts  line: 86  severity: low
Host-supplied strings (commit/fromCommit from the outbox's available.json, validated only as z.string()) are interpolated unvalidated into imperative shell commands the owner is instructed to run ('git merge --ff-only ${commit}'). A tampered or buggy host file can inject shell into owner-facing instructions; validate SHA shape before embedding.

