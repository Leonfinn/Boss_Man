# Change c05 — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c05.diff

ANSWER KEY: file apps/server/src/services/notifications.ts, line ~171, type: inverted check
Bug: The unread/read filters are swapped: Unread returns read notifications and vice versa.

## Findings (anonymous ids)

### c05-G001
file: apps/server/src/services/notifications.ts  line: 171  severity: high
Status filter is inverted: status=unread applies isNotNull(notifications.readAt) and status=read applies isNull(notifications.readAt), so requesting unread returns already-read notices and vice versa. unread() in the same service defines unread as isNull(readAt), and the new server test in this PR expects status=unread to return the never-read rows (b, c), so that test fails against this code.

### c05-G002
file: apps/web/src/pages/Notifications.tsx  line: 243  severity: low
readFilters validates the persisted level with `s.level in LEVEL`, which also matches inherited Object.prototype keys ("constructor", "toString", ...), so a corrupt sessionStorage value is accepted as a NotifyLevel and sent to the server, which rejects it with 400; the filtered view then stays on the error banner until the user clears filters, contradicting the 'anything unreadable falls back to All' contract. Line 244 has the same gap for company: any non-empty string is kept and sent as company=... (400 until the companies list loads and the missing-company fallback applies).

### c05-G003
file: apps/server/src/services/notifications.ts  line: 171  severity: high
The status filter is inverted: status=unread filters isNotNull(readAt) (rows that HAVE been read) and status=read filters isNull(readAt). Unread means readAt is null — the service's own unread() count uses isNull(readAt) and the client treats !n.readAt as unread — so both branches are swapped. The Unread/Read tabs will show the opposite set, and the new server test in this same PR (after marking 'a' read, expects status=unread → [b, c] and status=read → [a]) would fail against this code.

### c05-G004
file: apps/web/src/pages/Notifications.tsx  line: 326  severity: low
When the active filter's request has not resolved (or failed), items falls back to last.current, which still holds the previous filter's results. After a failed filtered fetch the list therefore renders notices that do not match the active filters as if they do — the 'No notifications match' guard is skipped and only the error banner hints anything is wrong. Relatedly, last.current is mutated during render (line 325), so items from a render that React discards can still be committed to the ref and shown later.

