# Change c13 — CLEAN CONTROL (no seeded bug)
Diff the models saw: /tmp/bakeoff/diffs/c13.diff

## Findings (anonymous ids)

### c13-G001
file: apps/server/src/services/watchdog.ts  line: 910  severity: low
actions() now costs up to 4 sequential round trips per call instead of 1, and the company-prefix query at this line runs unconditionally even when `rows` is empty (unlike the guarded targets/decisions lookups). This endpoint is polled every 15s per open Scrum Master log. Fetch the prefix in parallel with the main query (or skip it when rows is empty) and run the targets/decisions lookups with Promise.all.

### c13-G002
file: apps/server/src/services/watchdog.ts  line: 912  severity: low
The agents lookup (and the decisions lookup on line 914) is not scoped by companyId, unlike every other query in this function. It is only safe because targetAgentId/after.decisionId are server-written for the same company; any stray or future cross-company id would silently expose another tenant's agent name or decision question. Add eq(agents.companyId, companyId) / eq(decisions.companyId, companyId) for defense in depth.

### c13-G003
file: apps/server/src/services/watchdog.ts  line: 912  severity: low
The new agents lookup filters only by id (inArray) with no companyId condition. targetAgentId comes from company-scoped action rows so it is safe today, but nothing enforces that invariant; a stray or cross-company id would return and display another tenant's agent name/role/duty. Add eq(agents.companyId, companyId) as defense-in-depth.

### c13-G004
file: apps/server/src/services/watchdog.ts  line: 914  severity: low
Same gap for the decisions lookup: decisionId is read out of the free-form after JSON column with no validation, and the query has no companyId filter, so a wrongly stored id would surface another company's decision question text in this company's activity log. Scope it with eq(decisions.companyId, companyId).

### c13-G005
file: apps/web/src/components/ScrumMasterLog.tsx  line: 31  severity: low
For alert_hop, a null targetName renders "Warning passed to you". That conflates "hopped to the owner (no targetAgentId recorded)" with "target agent no longer resolvable" (e.g. the agent row was hard-deleted), wrongly telling the owner they hold a warning that was actually passed to a teammate. Fall back to the plain label or an explicit unknown-target wording instead of "you".

