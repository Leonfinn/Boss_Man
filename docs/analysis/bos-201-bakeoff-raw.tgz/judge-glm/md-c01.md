# Change c01 — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c01.diff

ANSWER KEY: file apps/server/src/services/review.ts, line ~474, type: off-by-one / boundary
Bug: The lock-wait retry loop allows LOCK_RETRY_ATTEMPTS+1 tries (one more than the 6 stated); the give-up check should be >=.

## Findings (anonymous ids)

### c01-G001
file: apps/server/src/services/review.ts  line: 472  severity: high
Off-by-one in the retry loop: the give-up check `attempt > LOCK_RETRY_ATTEMPTS` runs *after* landOnce, so the merge check is executed LOCK_RETRY_ATTEMPTS + 1 = 7 times, not 6. The per-try records say "try N of 6" and the final record says "after 7 tries", contradicting LOCK_RETRY_ATTEMPTS=6; worse, the committed test asserts `toHaveLength(LOCK_RETRY_ATTEMPTS)` (6 verify sends), so that test fails as written. The comparison should be `attempt >= LOCK_RETRY_ATTEMPTS` (or the check should happen before calling landOnce).

### c01-G002
file: apps/server/src/services/review.ts  line: 488  severity: low
When the ticket left review during the pause, the loop returns outcome "check_stuck" even though no decision was raised on this path. landingText for check_stuck tells the reader the matter "is in your Decisions" (per the existing test), which is false here — the ticket was e.g. sent back or finished. Reusing check_stuck for an aborted wait produces a wrong owner-facing message; it needs its own outcome or text.

### c01-G003
file: apps/server/src/services/review.ts  line: 563  severity: low
The checkResults row with passed: false is inserted before the new lock-wait classification, so every retry records a *failed* verify for a run in which no check step actually ran — up to 7 "failed" rows per merge. This contradicts the change's own premise ("nothing the agent wrote failed") and pollutes check history; lock waits should be recorded distinctly or not as failures.

### c01-G004
file: scripts/check-all.sh  line: 71  severity: low
`SECONDS` is a bashism; the script is otherwise POSIX sh and the runner executes checks via `sh -c`. If the shebang is #!/bin/sh (dash on Debian/Ubuntu), SECONDS is unset, `[ "$SECONDS" -lt "$end" ]` errors, and the hand-run poll loop body never executes — a busy lock, or a waiting merge check, then makes hand-run checks exit 75 immediately instead of waiting up to WAIT seconds, breaking both the wait behavior and the merge-priority scheme. Use a manual counter or `date +%s`.

### c01-G005
file: apps/server/src/services/review.ts  line: 474  severity: medium
Off-by-one: the give-up check `attempt > LOCK_RETRY_ATTEMPTS` is evaluated after landOnce, so the check runs LOCK_RETRY_ATTEMPTS+1 = 7 times, not 6. The new test asserts exactly 6 workspace.verify sends (`toHaveLength(LOCK_RETRY_ATTEMPTS)`), so it fails as written. The progress messages ('try N of 6') and the give-up message ('after 7 tries') also contradict the configured count, and the worst-case wait doubles (~63 min of pauses plus an extra up-to-600s lock wait, all while the landing/approval is held open).

### c01-G006
file: apps/server/src/services/review.ts  line: 490  severity: medium
The post-pause guard only checks tickets.systemState === 'review'. If the ticket leaves review during the pause (e.g. the CEO answers an older decision with send-back) and the agent moves it back to review before the check runs, the loop resumes and merges without fresh approvals, bypassing the new round's pending reviews. It should re-verify that the approval still stands (e.g. evaluate(rows) === 'passed'), not just the state string.

### c01-G007
file: apps/server/src/services/review.ts  line: 490  severity: low
When the ticket left review during the pause, the abort returns outcome 'check_stuck' even though no decision was created; landingText renders check_stuck as "it's in your Decisions", pointing the owner at a decision that doesn't exist.

### c01-G008
file: apps/server/src/services/review.ts  line: 563  severity: low
The checkResults insert runs before the lock-wait classification, so every retry records a failed verify (passed: false) for the head sha. After exhaustion the ticket's check history shows ~7 failures although the messaging says 'Nothing failed; no need to run it by hand', misleading any UI or PR-check surfacing built on checkResults.

### c01-G009
file: scripts/check-all.sh  line: 56  severity: low
Waiter files are keyed by PID and only the EXIT trap removes them; a merge check killed with SIGKILL (runner timeout/cancel kills the process group) leaves a stale file. If that PID is reused before the next merge_waiting() scan, kill -0 succeeds and hand-run checks are kept out of a free lock (exiting 75 after WAIT) until the unrelated process happens to die.

