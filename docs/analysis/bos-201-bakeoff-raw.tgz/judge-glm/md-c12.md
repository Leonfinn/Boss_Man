# Change c12 — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c12.diff

ANSWER KEY: file apps/server/src/services/work.ts, line ~197, type: wrong condition (&& became ||)
Bug: Chat runs now count as working on any ticket (|| instead of &&), so every card shows chat agents as working.

## Findings (anonymous ids)

### c12-G001
file: apps/server/src/services/work.ts  line: 197  severity: high
onCard's first disjunct `r.purpose !== "chat"` doesn't reference the ticket, so it is true for every ticket id: every non-chat live run in the company is reported in `working`/`workingSince` on every card on the board, and `withoutCard` discards every non-chat run whenever the board has at least one ticket, so the new strip only ever lists chat runs — the opposite of the ticket's goal. The stated rule ("on it (chat runs don't) or about it via runTicketId") needs `(r.ticketId === id && r.purpose !== "chat") || r.runTicketId === id`; as written it also makes chat runs on a ticket count, which the comment says shouldn't. The new test passes only because it checks one card and the only other live run is a chat run; e.g. a review-wake run naming several tickets (ticketId null, runTicketId null, purpose not "chat") would light up every card and never appear in the strip.

### c12-G002
file: apps/server/src/services/work.ts  line: 229  severity: low
`workingAgents` counts distinct agents with live runs across the whole company, but the chip it feeds is a filter over this board's cards: on a multi-project company (or when agents are only running ticketless chats) the "Working now (N)" count includes agents that no click of the filter can show. Dashboard parity is the stated goal, but the number is displayed on a board-scoped control while describing a different set.

### c12-G003
file: apps/web/src/pages/Board.tsx  line: 645  severity: low
`Working now${board.data ? ` (${board.data.workingAgents})` : ""}` renders "Working now (undefined)" whenever the field is absent (e.g. web deployed before the server). The base test stub was not given the new required Board fields and the assertions were loosened to /^Working now/, so the tests exercise this path and mask it instead of catching it; guard the interpolation or update the stub.

### c12-G004
file: apps/server/src/services/work.ts  line: 230  severity: low
The strip is titled "Working without a ticket", but `withoutCard` also catches runs attached to tickets that simply aren't on this board (another project's ticket) and — once the onCard predicate is fixed — chat runs on this board's tickets. Their `ticket`/`ticketId` are returned but never rendered (Board.tsx only passes wakeNote to RunLabelLink), so those runs appear under a "without a ticket" heading with no indication of which ticket they're on.

### c12-G005
file: apps/server/src/services/work.ts  line: 197  severity: high
onCard mis-groups its conditions: `r.purpose !== "chat" || r.ticketId === id` is true for every non-chat run no matter which ticket it belongs to. Consequences: (1) every non-chat live run in the company is counted as working on every card — line 219 puts all such agents on each card's `working` list and line 221 makes `workingSince` the earliest company-wide start, not the run on that ticket; (2) a chat run whose ticketId is on the board is counted, although chat runs shouldn't be (the old query excluded them); (3) in withoutCard (line 199), onCard is true for every ticket id for any non-chat run, so whenever the board has at least one ticket every non-chat live run is dropped from the strip — 'Working without a ticket' ends up listing only chat runs while the ticketless non-chat runs it exists to show never appear. The intended predicate is `(r.purpose !== "chat" && r.ticketId === id) || r.runTicketId === id`. The new server test passes only because its board has a single ticket and the CEO run happens to be a chat run.

### c12-G006
file: apps/web/src/pages/Board.tsx  line: 645  severity: low
The chip's count is company-wide: workingAgents counts every agent with a live run, including chat runs, ticketless runs and runs on other projects. But the filter it labels only shows this project's cards with live work, so the number on the button generally won't match what clicking it displays (e.g. '(3)' filtering to 1 card). If the count is meant to advertise the dashboard figure, it shouldn't sit on a filter chip whose result set is board-scoped.

