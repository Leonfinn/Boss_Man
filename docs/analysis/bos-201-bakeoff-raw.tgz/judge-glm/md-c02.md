# Change c02 — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c02.diff

ANSWER KEY: file apps/server/src/services/decisions.ts, line ~1356, type: missing permission / authorisation check
Bug: Removed the guard that stops the CEO (settledBy) from answering 'Let the CEO decide' itself; the hand-off is meant to be owner-only.

## Findings (anonymous ids)

### c02-G001
file: apps/server/src/services/decisions.ts  line: 1358  severity: high
Nothing in the diff checks who is answering before handToCeo runs, yet the new test ('a CEO agent can't hand the card back to itself') expects an agent answer (settledBy set) to be rejected with an 'Only the owner' AnswerError. No code added here produces that error. If no base guard supplies it, the test fails and a CEO agent can re-answer 'Let the CEO decide' on the already-handed-off (tier 'ceo') card via the decisions tool: handToCeo re-runs, resets ladder.since, re-wakes the CEO, and the card never climbs back to the owner — exactly the abuse the test claims to prevent. If a base guard keyed on settledBy/forAgentId does supply the rejection, then handToCeo's forAgentId: null likely locks the CEO out of answering the handed-off card via the agent path at all — and no test exercises that path (the 'who can then reassign it' test performs the CEO's reassign through the owner's HTTP session, not as the agent).

### c02-G002
file: apps/server/src/services/decisions.ts  line: 635  severity: medium
The CEO wake note wraps d.question with untrusted() but interpolates blocker.title raw: `(the blocking ticket is "${blocker.title}")`. Ticket titles are agent-controlled text, so an agent can place arbitrary unwrapped content into the CEO's wake prompt — precisely the surface this commit claims to have wrapped as untrusted.

### c02-G003
file: apps/server/src/services/decisions.ts  line: 635  severity: low
The wake note instructs the CEO to answer with 'Chase, Reassign (give assigneeAgentId) or Drop dependency' for every handed-off card, but engagement-blocker cards have no blockerTicketId and Reassign is refused ('Only a ticket can be reassigned.'), so for those cards the CEO is told to attempt an option the card does not have.

### c02-G004
file: apps/server/src/services/decisions.ts  line: 1355  severity: high
The owner-only rule is not implemented: `handOff` is computed only from the card's context type and the answer string, `validate()` never inspects `extra.settledBy`, and `handToCeo()` ignores who is answering. The new test expecting `rejects.toThrow("Only the owner")` for `svc.answer(id, "Let the CEO decide", { settledBy: { agentId: ceo } })` therefore has no matching check in this diff — it either fails, or passes only because some pre-existing agent gate refuses all agent answers on these cards, which would also break the CEO's promised Chase/Reassign/Drop answers (nothing actually exercises a CEO agent answering the handed card; the "CEO's answer carries out the owner's options" test posts as the owner). As written, a CEO agent can answer "Let the CEO decide" via the decisions tool (the handed card is tier "ceo", so the tool's tier/mine checks pass) and hand the card to itself — exactly what the new test says must be refused.

### c02-G005
file: apps/server/src/services/decisions.ts  line: 623  severity: medium
`handToCeo` doesn't refuse a card that is already at the CEO rung: every call rewrites `ladder.since`/`hops`, re-inserts the "decision_answered" activity row and re-wakes the CEO, granting a fresh escalation window each time. Repeated "Let the CEO decide" answers (an owner replaying POST /api/decisions/:id/answer, or the CEO given the missing guard above) can keep the card off the owner's queue indefinitely. It should no-op or throw when `d.tier === "ceo"` / `ctx.ladder?.rung === "ceo"`.

### c02-G006
file: apps/server/src/services/decisions.ts  line: 635  severity: medium
The CEO wake note wraps `d.question` with `untrusted(...)` but then interpolates the blocking ticket's title raw: `(the blocking ticket is "${blocker.title}")`. Ticket titles are agent-controlled text, so untrusted content reaches the CEO agent outside the untrusted wrapper — the prompt-injection vector the commit message claims to have closed.

### c02-G007
file: apps/server/src/services/decisions.ts  line: 635  severity: low
The same wake note instructs the CEO to answer "Chase, Reassign (give assigneeAgentId) or Drop dependency" for every handed card, but for engagement-blocker cards (no `blockerTicketId`) Reassign is invalid ("Only a ticket can be reassigned"), so the CEO is told to do something the server will refuse; the sentence also degrades to "settle this ." when there is no blocker ticket.

