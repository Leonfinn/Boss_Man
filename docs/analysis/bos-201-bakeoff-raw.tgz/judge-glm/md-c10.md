# Change c10 — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c10.diff

ANSWER KEY: file apps/server/src/services/review.ts, line ~369, type: race / ordering
Bug: Removed the claim of the landing before the first await, so two simultaneous approvals can both start a landing.

## Findings (anonymous ids)

### c10-G001
file: apps/server/src/services/review.ts  line: 367  severity: high
The comment (and the commit message 'claims the landing before its first await') is false: landings.set(ticketId, running) at line 386 still executes only after `await ticketWithRepo(ticketId)` at line 371. The 409 guard at line 366 and the claim are not atomic, so two concurrent approvals (or an approval racing the sweep) can both pass the guard while suspended at the first await, then both set the map and both spawn the background land() — two concurrent verify/merge runs sharing one worktree, duplicate merge/closure attempts, and duelled landing-status writes. The race this change claims to fix is left in.

### c10-G002
file: apps/server/src/services/review.ts  line: 373  severity: medium
landings.delete(ticketId) in the new error path deletes an entry this call never stored (nothing is set before the await). While this call is suspended inside ticketWithRepo, another request can pass the guard and set a live 'running' claim; if this call's ticketWithRepo then throws, the delete wipes that live claim, re-opening the guard so a further landing can start beside a still-running one. It also deletes a previous landing's 'finished' record that the /landing poll endpoint serves. The delete only makes sense paired with a claim set before the first await, which is exactly what's missing.

### c10-G003
file: apps/server/src/services/review.ts  line: 425  severity: low
The widened catch now handles every error, but its own handling (the ticket select here, then record/raiseMergeStuck) runs against the same database that produced the error. When the caught error is a database failure — the exact 'database is locked' case the new test simulates, except there the DB still works — these statements will typically throw as well, discard the original error, and the approved ticket is still left with no merge_failed record and no card. The guarantee the change advertises ('never leaves the ticket silent') does not hold for DB-originated errors; there is no retry or fallback around the handler's own queries.

### c10-G004
file: apps/server/src/services/review.ts  line: 386  severity: high
The landing is not claimed before the first await: landings.set(ticketId, running) runs only after `await ticketWithRepo(ticketId)` (line 371), so the `state === "running"` guard at line 366 is still a check-then-act across an await point. Two approvals submitted at the same moment (or an approval racing the sweep) both pass the guard and both start a landing — exactly the double-landing race the new comment (line 367) and the commit message claim to fix. Consequences: two concurrent land() runs (duplicate verify runs, racing git merges) and the second "running" status silently overwriting the first. A placeholder running entry must be set before the await.

### c10-G005
file: apps/server/src/services/review.ts  line: 373  severity: medium
landings.delete(ticketId) in the new catch deletes an entry this call never set: a previous attempt's "finished" record disappears from the landing endpoint the page polls, and — combined with the guard race above — it can delete a "running" entry a concurrent startLanding just installed, reopening the guard while a landing is actually in flight. Recording a failed/finished landing status instead of deleting would preserve the trail this feature is meant to keep.

### c10-G006
file: apps/server/src/services/review.ts  line: 381  severity: low
After recording merge_failed and raising the merge-stuck card, the original error is rethrown, so the reviewer's approve call fails with the raw underlying error even though the approval was recorded and a card raised. A reviewer who retries records the approval a second time; the response should reflect the recorded state (e.g. a ReviewError saying the merge couldn't start and a card was raised).

### c10-G007
file: apps/server/src/services/review.ts  line: 372  severity: low
The new "merge couldn't start" path (ticketWithRepo rejection → delete + record + raiseMergeStuck) has no test coverage; the added tests only exercise landOnce rejections inside land(). Given this path also contains the landing-map deletion above, it needs a test that makes ticketWithRepo reject.

