# Change c06 — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c06.diff

ANSWER KEY: file apps/server/src/services/decisions.ts, line ~658, type: error swallowed
Bug: The wake of the CEO for a plan now swallows any failure, so a plan can sit on the ceo rung with nobody woken and no trace.

## Findings (anonymous ids)

