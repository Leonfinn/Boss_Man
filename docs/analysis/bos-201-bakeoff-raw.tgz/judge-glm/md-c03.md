# Change c03 — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c03.diff

ANSWER KEY: file apps/server/src/services/decisions.ts, line ~697, type: wrong condition (security: allow-list bypass)
Bug: The allow-list of tool-input keys now passes when ANY key is a Bash key instead of ALL, so a command carrying an extra key like workdir/cwd is treated as running in the working copy.

## Findings (anonymous ids)

### c03-G001
file: apps/server/src/services/decisions.ts  line: 697  severity: high
The tool-input allow-list is inverted: `Object.keys(raw).some((k) => SHELL_INPUT_KEYS.has(k))` passes when AT LEAST ONE key is a known Bash key, but the stated intent (comment here and in explain.ts, and the new test "goes to the owner ... tool input with any key Claude Code's Bash tool doesn't send") is that ALL keys must be known. With `some`, an input like `{ command: "rm -rf dist", workdir: "/srv/app" }` (opencode's workdir, codex's cwd — exactly the cases the comment says could point the command elsewhere) still yields files=["dist"], gets the run.workspace lookup, and goes to the CEO with a card asserting the paths are in the ticket's checkout, while the command actually runs in the other directory. It should be `.every(...)` (or `!some(k => !SHELL_INPUT_KEYS.has(k))`). As written, the new test's seven rawInput cases expect tier "owner" but would get "ceo", so the shipped test fails.

### c03-G002
file: apps/server/src/services/decisions.ts  line: 695  severity: medium
The "deletes are in the agent's own working copy" guarantee is not established. The no-`cd` check only covers the requested command, but the shell's working directory persists across the run's earlier commands, and plain `cd <dir>` is auto-allowed by the default "Other shell commands" rule; the run.workspace event only speaks to where the run started. So an agent (or prompt-injected agent) can run `cd /var/www/app` in an earlier auto-allowed command, then request `rm -rf dist`: cleanupScope sees no cd, the server trusts run.workspace, and the CEO gets "In X's working copy for TICKET (branch Y): dist" plus "It has no cd." — a location claim the server cannot verify — with a pre-selected Allow (build-output name) and a 5-minute fallback, bypassing the owner gate for a delete that resolves outside the checkout. The code comment admits it "can't see where the shell is now", yet the card and wake note assert the location as fact; either the cwd must be established (e.g., runner reports cwd per request) or the card must not claim it.

### c03-G003
file: apps/server/src/services/decisions.ts  line: 748  severity: low
A command mixing working-copy deletes with /tmp deletes still reaches the CEO under the working-copy wake note, which drops the BOS-111 caveats. E.g. `rm -rf /tmp/x && rm -rf dist && git worktree add -b x /tmp/x` passes cleanupScope (the /tmp delete clears the worktree target), routes to WORKING_COPY_RULE, and the CEO receives only the working-copy guidance — no "git worktree add writes into the project's .git: check the branch name is the asking agent's own" and no install-scripts warning, even though the command contains those constructs. The temp-cleanup branch of the note carries those warnings; the working-copy branch should keep them for mixed commands (or mixed commands should get both).

### c03-G004
file: apps/server/src/services/decisions.ts  line: 697  severity: high
The tool-input allow-list is inverted: Object.keys(raw).some((k) => SHELL_INPUT_KEYS.has(k)) accepts any input that merely contains one known key, so { command, cwd } (or workdir/tool_input — exactly the opencode/codex shapes the comment says must be excluded) passes the check. The request is then routed to the CEO as WORKING-COPY CLEANUP with the claims that the paths are relative to the ticket's worktree and 'It has no cd', even though the unrecognized key may name the folder the command actually runs in. It must be .every(...) so that only pure Claude Code Bash input is trusted. The PR's own tests expect tier 'owner' for these inputs (the { cwd: ... }, { workdir: ... }, { tool_input: ... } cases), so they fail as written.

### c03-G005
file: apps/server/src/services/decisions.ts  line: 749  severity: medium
The card and wake note assert the deletes are 'in X's working copy' and 'It has no cd', but cleanupScope's cd ban only covers the current command. Claude Code's Bash tool keeps a persistent shell whose working directory persists across tool calls, and a plain earlier `cd /somewhere` is auto-allowed by the defaults ('Other shell commands' → allow), so a later `rm -rf dist` can resolve outside the checkout while run.workspace still says the run started in it. The server cannot see the shell's current directory, so — unlike the symlink risk, which the note does disclose — the location claim presented to the CEO can be false. The run.workspace check pins where the run started, not where the shell is now; the note should not state the location as fact (or the runner must report cwd per request).

