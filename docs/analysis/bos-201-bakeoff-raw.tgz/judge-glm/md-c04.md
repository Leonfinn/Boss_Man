# Change c04 — HAS a seeded bug
Diff the models saw: /tmp/bakeoff/diffs/c04.diff

ANSWER KEY: file apps/server/src/services/planning.ts, line ~234, type: wrong variable
Bug: blockIds maps to e.blocker (the ticket itself) instead of e.blocked, so the 'Blocks' group is always empty.

## Findings (anonymous ids)

### c04-G001
file: apps/server/src/services/planning.ts  line: 234  severity: high
blockIds maps e.blocker instead of e.blocked. For every edge where this ticket is the blocker, e.blocker is the ticket's own id, so byIds() fetches only the ticket itself and others() strips it — the blocks list is always empty. Combined with the removal of the 'Waiting on this' list from TicketLinks.tsx in the same change, 'which tickets wait on this one' is now visible nowhere. The new test only asserts blocks === [] with no blocked-by fixture, so it passes despite the bug.

### c04-G002
file: apps/server/src/services/planning.ts  line: 220  severity: low
children and both sibling queries silently cap at limit(200) ordered by number, so a feature or parent with more than 200 tickets quietly drops peers/sub-tasks (and, if >200 children, a late child sharing the feature can even surface as a peer via the incomplete childIds set). The UI's 'show N more' implies a complete list; there is no truncation indicator or pagination.

### c04-G003
file: apps/server/src/services/planning.ts  line: 234  severity: high
blockIds maps e.blocker instead of e.blocked. For edges where this ticket is the blocker, the other ticket is e.blocked, so blockIds is just [ticketId, ...]; byIds then returns the ticket itself and others() filters it out, making `blocks` always empty. Because this change also removes the 'Waiting on this' (links.data.blocks) list from TicketLinks.tsx, tickets blocked by this ticket are no longer visible anywhere on the ticket page. The new test asserts r.blocks is empty without ever creating a ticket blocked by `me`, so it passes vacuously and hides the bug.

### c04-G004
file: apps/server/src/services/planning.ts  line: 220  severity: low
children (and the two sibling queries at lines 222-223) are silently capped at limit(200) with no indication to the client; the UI's 'show N more' control then implies a complete list while subtasks/peers beyond the cap are dropped. Additionally, childIds is built from the capped children list, so a sub-task beyond 200 that also shares the feature would be misclassified as a peer instead of a sub-task.

