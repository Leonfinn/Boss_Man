# Change c14 — CLEAN CONTROL (no seeded bug)
Diff the models saw: /tmp/bakeoff/diffs/c14.diff

## Findings (anonymous ids)

### c14-G001
file: apps/server/src/services/alert-ladder.ts  line: 91  severity: medium
dueAt gates the CEO→owner fall-through solely on CEO run rows and ignores holder()'s skip conditions (company paused, CEO paused or over its hourly cap; only a missing CEO is special-cased). When the CEO can't be woken, no run will ever start, so the card now waits out the 20-minute outer cap before reaching the owner instead of the previous `minutes` (5) — tripling the worst-case delay and contradicting the documented 'when the company is paused it goes straight to the owner'.

### c14-G002
file: apps/server/src/services/alert-ladder.ts  line: 92  severity: low
ladder.since is when the card reached its current rung (per the Ladder type doc), not when it was raised. For cards that climbed from scrum_master, both the 20-minute outer cap and the 'first CEO run after the raise' lower bound actually count from the hop to the CEO rung, so total time to the owner can be the SM window + 20 minutes — contradicting the comment on CEO_OUTER_CAP_MINUTES ('counted from when it was raised') and the commit message ('cap at 20 min from raise'). Cards created directly at CEO tier are unaffected.

### c14-G003
file: apps/server/src/services/alert-ladder.ts  line: 275  severity: low
The escalation reason passed to place() still reads 'didn't settle it within ${minutes} minutes', but under the new clock the card can move at the outer cap (e.g. 20 minutes) because no CEO run ever started. The recorded reason/triedFirst text then asserts a CEO window that never existed (the CEO was never woken into a run), misleading the owner and the audit log.

