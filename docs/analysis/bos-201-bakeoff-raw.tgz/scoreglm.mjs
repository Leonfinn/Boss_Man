import fs from "node:fs";
const O="/tmp/bakeoff",K=JSON.parse(fs.readFileSync(`${O}/key/answer-key.json`)),M=JSON.parse(fs.readFileSync(`${O}/judge-glm/md-map.json`));
const L={};for(const k of K)Object.assign(L,JSON.parse(fs.readFileSync(`${O}/judge-glm/labels-${k.id}.json`)));
const res={};for(const [id,m] of Object.entries(M)){const l=L[id];if(!l){console.log("missing",id);continue}
 const r=(res[id.slice(0,3)+"-r"+m.run]??={C:0,S:0,R:0,F:0});r[{CATCH:"C",SYMPTOM:"S",REAL:"R",FALSE:"F"}[l.label]]++}
const o={catch:0,sym:0,F:0,Fctl:0,R:0,rev:0,okrev:0,byType:{},cons:{both:0,one:0,none:0},perChange:{},api:[],pt:0,ot:0};
for(const k of K)for(const n of [1,2]){const j=JSON.parse(fs.readFileSync(`${O}/out-glm-think/glm/${k.id}-r${n}.json`));o.rev++;o.api.push(j.apiMs);o.pt+=j.promptTokens;o.ot+=j.outputTokens;if(j.ok)o.okrev++}
for(const k of K){const rr=[1,2].map(n=>res[`${k.id}-r${n}`]??{C:0,S:0,R:0,F:0});
 rr.forEach(r=>{o.F+=r.F;o.R+=r.R;if(k.kind=="control")o.Fctl+=r.F});
 if(k.kind=="bug"){const cs=rr.map(r=>r.C>0);const n=cs.filter(Boolean).length;o.catch+=n;o.sym+=rr.filter(r=>r.C==0&&r.S>0).length;o.cons[n==2?"both":n==1?"one":"none"]++;
  o.perChange[k.id]=`${k.type}: r1 ${rr[0].C?"C":rr[0].S?"S":"-"}, r2 ${rr[1].C?"C":rr[1].S?"S":"-"}`;(o.byType[k.type]??=[0,0]);o.byType[k.type][0]+=n;o.byType[k.type][1]+=2}}
o.apiAvgSec=Math.round(o.api.reduce((a,b)=>a+b,0)/o.rev/1000);delete o.api;console.log(JSON.stringify(o,null,1));
