import fs from "node:fs";
const O="/tmp/bakeoff",K=JSON.parse(fs.readFileSync(`${O}/key/answer-key.json`));const map={};let tot=0,bad=[];
for(const k of K){let md=`# Change ${k.id} — ${k.kind==="bug"?"HAS a seeded bug":"CLEAN CONTROL (no seeded bug)"}\nDiff the models saw: /tmp/bakeoff/diffs/${k.id}.diff\n\n`;
 if(k.kind==="bug")md+=`ANSWER KEY: file ${k.file}, line ~${k.seededLine}, type: ${k.type}\nBug: ${k.bug}\n\n`;
 md+="## Findings (anonymous ids)\n\n";let n=0;
 for(const r of [1,2]){const j=JSON.parse(fs.readFileSync(`${O}/out-glm-think/glm/${k.id}-r${r}.json`));if(!j.ok){bad.push(k.id+"-r"+r);continue}
  const b=[...j.content.matchAll(/```json\s*([\s\S]*?)```/g)];let f=null;try{f=JSON.parse(b[b.length-1][1])}catch{}
  if(!Array.isArray(f)){bad.push(k.id+"-r"+r+" unparsed");continue}
  for(const x of f){n++;const id=`${k.id}-G${String(n).padStart(3,"0")}`;map[id]={model:"glm-think",run:r};md+=`### ${id}\nfile: ${x.file}  line: ${x.line}  severity: ${x.severity}\n${x.reason}\n\n`}}
 tot+=n;fs.writeFileSync(`${O}/judge-glm/md-${k.id}.md`,md)}
fs.writeFileSync(`${O}/judge-glm/md-map.json`,JSON.stringify(map));console.log(tot,bad);
